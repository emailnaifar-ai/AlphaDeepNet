"""Word response letters (combined + one per reviewer) with native Word equations (OMML)."""
import os, re, copy, sys
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from latex2mathml.converter import convert
from lxml import etree

OUT = sys.argv[1]
XSL = etree.XSLT(etree.parse(r"C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL"))
TITLE = ("AlphaDeepNet: A shifted log-ratio theory of adaptive alpha-gating, "
         "with validation on positive-state forecasting")
RED, GREEN, NAVY, GREY = RGBColor(0xC8, 0, 0), RGBColor(0, 0x7D, 0x3C), RGBColor(0x1F, 0x3A, 0x68), RGBColor(0x40, 0x40, 0x40)


# ------------------------------------------------------------------ helpers
def omml(latex):
    return copy.deepcopy(XSL(etree.fromstring(convert(latex))).getroot())


def rich(p, text, size=11, color=None, italic=False):
    """Add text with **bold** and $inline math$ markup to paragraph p."""
    for tok in re.split(r"(\$[^$]+\$|\*\*[^*]+\*\*)", text):
        if not tok:
            continue
        if tok.startswith("$"):
            p._p.append(omml(tok[1:-1]))
            continue
        bold = tok.startswith("**")
        r = p.add_run(tok[2:-2] if bold else tok)
        r.bold = bold; r.italic = italic; r.font.size = Pt(size)
        if color is not None:
            r.font.color.rgb = color


def para(doc, text="", size=11, color=None, italic=False, align=None, after=6, before=0, indent=None):
    p = doc.add_paragraph()
    pf = p.paragraph_format; pf.space_after = Pt(after); pf.space_before = Pt(before)
    pf.line_spacing = 1.08
    if indent is not None:
        pf.left_indent = Cm(indent)
    if align:
        p.alignment = align
    rich(p, text, size, color, italic)
    return p


def bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(3); p.paragraph_format.line_spacing = 1.08
    rich(p, text)
    return p


def equation(doc, latex):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(6)
    mp = OxmlElement("m:oMathPara"); mp.append(omml(latex)); p._p.append(mp)


def shade(p, fill="F2F2F2"):
    pPr = p._p.get_or_add_pPr(); shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), fill)
    pPr.append(shd)


def comment(doc, label, text):
    h = para(doc, f"**{label}**", size=11.5, color=NAVY, before=10, after=3)
    h.paragraph_format.keep_with_next = True
    for chunk in text.strip().split("\n\n"):
        p = para(doc, chunk.strip(), size=10.5, color=GREY, italic=True, after=4, indent=0.3)
        p.paragraph_format.keep_with_next = True
        shade(p)


def label(doc, text, color=NAVY):
    p = para(doc, f"**{text}**", color=color, after=2, before=4)
    p.paragraph_format.keep_with_next = True
    return p


def table(doc, header, rows, widths=None, bold_cells=()):
    t = doc.add_table(rows=1 + len(rows), cols=len(header)); t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER; t.autofit = False
    widths = widths or [6.0] + [10.4 / (len(header) - 1)] * (len(header) - 1)
    for i, row in enumerate([header] + rows):
        for j, val in enumerate(row):
            c = t.cell(i, j); c.text = ""; c.width = Cm(widths[j])
            p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER if j else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.keep_with_next = i < len(rows)
            rich(p, f"**{val}**" if (i == 0 or (i, j) in bold_cells) else val, size=9.5)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def new_doc():
    d = Document()
    st = d.styles["Normal"]; st.font.name = "Times New Roman"; st.font.size = Pt(11)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    for s in d.sections:
        s.left_margin = s.right_margin = Cm(2.3); s.top_margin = s.bottom_margin = Cm(2.0)
    return d


def header(doc, subtitle):
    para(doc, f"**{subtitle}**", size=15, color=NAVY, align=WD_ALIGN_PARAGRAPH.CENTER, after=4)
    para(doc, f"Manuscript: *{TITLE}*".replace("*", ""), size=10.5, align=WD_ALIGN_PARAGRAPH.CENTER, after=2, italic=True)
    para(doc, "Journal: Neural Computing and Applications", size=10.5, align=WD_ALIGN_PARAGRAPH.CENTER, after=12)


# ------------------------------------------------------------------ content
R1 = {}
R1["General"] = ("Reviewer 1 — summary and strengths", """This manuscript presents a framework called "AlphaDeepNet" for forecasting positive-valued states by reformulating the classical adaptive alpha model in terms of a shifted log-ratio. [...] In general, the results suggest that the proposed formulation is particularly effective in reducing relative prediction error and, in most cases, MAE, although its advantage in terms of RMSE is less consistent.

Strengths: mathematical explanation of why the formulation should work; clear connection with the classical adaptive alpha model; sensible treatment of zeros; matched raw-versus-alpha comparisons; unfavourable results are not avoided; useful additional experiments; reproducibility.""")
R1[1] = ("Comment 1", """My main concerns the gap between the breadth of the proposed framework and the evidence presented for it. AlphaDeepNet is discussed in relation to feature gating, spatial representations, multimodal learning, segmentation, and medical imaging. Yet the empirical validation is entirely based on three positive-state time-series forecasting problems. The authors are quite transparent about this limitation, and they explicitly describe these other applications as future extensions. Nevertheless, I think these discussions currently occupy more space than the evidence warrants. The manuscript would be more focused if these extensions were shortened and clearly separated from the part of AlphaDeepNet that has actually been validated.""")
R1[2] = ("Comment 2", """I think the empirical evaluation could be broader. The three datasets are from different application areas, but they share the characteristics for which the proposed method is naturally well suited. They are nonnegative, covariate-driven time series. Testing the approach on additional datasets with different dynamics would make the generalizability argument more convincing.""")
R1[3] = ("Comment 3", """The choice of ε deserves more discussion as well. I agree with the authors that ε should be viewed as a modeling parameter rather than simply a numerical device. However, that also means its selection matters both for prediction and for the interpretation of the resulting alpha values. The validation-based sensitivity analysis is useful, but readers would benefit from more concrete guidance on how ε should be chosen in a new application and how sensitive the interpretation of alpha is to this choice.""")
R1[4] = ("Comment 4", """The theoretical section is rigorous, but it is also quite too long and dense. Some results appear to be included mainly for completeness, something the authors themselves acknowledge. I would consider moving the routine derivations and supporting results to the supplementary material. Doing so would make the theoretical contribution easier to follow and would probably improve the overall flow of the paper.""")
R1[5] = ("Comment 5 (recommendation)", """Overall, I find the central idea interesting and the paper technically strong. [...] I recommend reducing the emphasis on applications that have not yet been experimentally evaluated, providing clearer practical guidance on selecting ε, and streamlining some of the theoretical material. If possible, adding one or two more challenging datasets would also strengthen the empirical case considerably. The authors should retain the balanced discussion of the RMSE results.""")

R2 = {}
R2[1] = ("Comment 1", """The manuscript dedicates substantial theoretical space to feature, spatial, and multimodal applications, particularly referencing medical imaging. However, the authors explicitly admit these are "stated as future extensions rather than demonstrated capabilities". Including unvalidated modalities dilutes the paper's focus and artificially pads the theoretical contribution.""")
R2[2] = ("Comment 2", """The shift hyperparameter is critical to the model's well-posedness near zero. The main experiments use arbitrarily fixed values (1.0, 0.1, 1.0) based on "measurement resolution". A rigorous validation-based selection rule is only introduced post-hoc in Section 5.12, which reveals the fixed a priori values were suboptimal. This validation rule should have governed all primary experiments.""")
R2[3] = ("Comment 3", """The authors observe that the AlphaDeepNet parameterization occasionally yields higher Root Mean Square Error (RMSE) on bursty series, such as Appliance Energy. They justify this by explaining that log-ratio targets implicitly optimize relative rather than absolute error, meaning large spikes are under-penalized. While mathematically correct, framing this strictly as a "predictable consequence" minimizes a severe practical limitation; a model that systematically fails to capture peak loads is inherently disadvantaged in energy and environmental forecasting.""")
R2[4] = ("Comment 4", """The study claims practical competitiveness by augmenting strong baselines (LightGBM, N-BEATS, Transformers) with the alpha operator and showing improvement over the raw backbones. This proves the operator acts as a helpful inductive bias for those specific models, but it fails to benchmark against modern architectures inherently designed to handle heteroscedastic or heavily skewed positive-state data without manual log-ratio transformations.""")
R2[5] = ("Comment 5", """The core mechanism of learning a log-space residual is standard in time-series forecasting. However, the manuscript's distinct novelty lies in its rigorous, end-to-end mathematical translation of the classical Mellit et al. α-model into a constrained deep-learning operator. The theoretical proofs—specifically the shift-induced bias bound, exact log-state/log-ratio loss equivalence, and contractive stability guarantees—provide a sound, incremental contribution to the theory of multiplicative neural updates.""")
R2[6] = ("Comment 6", """The mathematical foundation is robust and the empirical ablation is rigorous, but the manuscript requires major revisions to address scope inflation (unvalidated multimodal claims) and inconsistent application of the shift hyperparameter.""")
R2[7] = ("Comment 7", """While the authors reference standard baselines (Transformers, N-BEATS, LightGBM), they exclude necessary comparisons to modern architectures specifically designed to handle heteroscedastic or heavily skewed positive-state data without requiring manual log-ratio transformations.""")
R2[8] = ("Final remark", """Therefore, I believe the proofs are solid and using a matched ablation study for empirical testing was very well done. In order to be published in Neural Computing and Applications the authors should drop their theory about spatial/multimodal data as there is no proof to back this up.""")


def where(doc, text, color):
    p = para(doc, f"**Changes in the manuscript** ({'red' if color == RED else 'green'} text): {text}", after=6)
    return p


# ---------------- Reviewer 1 responses ----------------
def r1_general(doc):
    comment(doc, *R1["General"])
    label(doc, "Response")
    para(doc, "We thank the reviewer for this careful reading and for recognising the theory, the matched-ablation design and the balanced reporting. Each weakness is answered below; every change made for this reviewer is shown in red in the revised manuscript and Supplementary Material.")


def r1_c1(doc):
    comment(doc, *R1[1])
    label(doc, "Response")
    para(doc, "We agree, and we went further than shortening: the paper now makes no statement about data it does not validate. All feature-gating, spatial, multimodal, segmentation and medical-imaging material has been removed, and the Introduction now states that “both the theory and the experiments of this paper concern this setting only” (positive-state forecasting).")
    bullet(doc, "**Removed:** the feature-gate, spatial-map and modality-fusion operators (Section 2); the classification/segmentation losses and feature/spatial/modality penalties (Section 3); the modality part of the identifiability theorem and the proposition on residual modality ambiguity (Section 4); the medical-imaging paragraph and medical baselines (Section 6); the corresponding sentences in the Abstract, Introduction, Limitations and Conclusion. The 17 references that supported only this material were removed (51 → 34).")
    bullet(doc, "**Clearly separated:** the operator is now defined only for scalar and vector positive states (Definition 2.4), with “the experiments use the scalar form” stated explicitly; Section 6 is renamed “Literature boundary and relation to nonlinear dynamics”.")
    bullet(doc, "Generic properties of a gate acting on features (norm/Lipschitz control, gradients, containment, scale identifiability) are kept only in Supplementary S1.1, explicitly labelled as not used by the experiments.")
    where(doc, "Abstract; Section 1 (paragraphs 2 and Contributions); Section 2 (Definition 2.4); Section 3; Section 4 (opening paragraph); Section 5.14; Section 6; Section 7; Supplementary S1.1.", RED)


def r1_c2(doc):
    comment(doc, *R1[2])
    label(doc, "Response")
    para(doc, "Thank you. The three datasets already differ in zero frequency (Beijing has exact zeros), tail heaviness (the top decile carries 26%, 32% and 78% of the squared error) and volatility (learned-gate standard deviation 0.10–0.33). To test generalizability beyond the two traits the reviewer identifies, we added a stress-test section (new Section 5.11, Table 12) that removes each trait in turn:")
    bullet(doc, "**No covariates** (target lags and calendar only), on all three datasets: the alpha version lowers sMAPE in **9/9** backbone–dataset cases, MAE in **8/9** and RMSE in **6/9**. The gain therefore does not rely on covariates.")
    bullet(doc, "**Intermittent, zero-inflated dynamics:** the household lighting load (77% exact zeros, 10 Wh resolution, on/off regime). The alpha version still lowers MAE for all three backbones (by 3–17%), but RMSE only for GBM, and persistence remains best in MAE.")
    para(doc, "We report the second result as the boundary of the method's useful range (Section 5.14) rather than omit it; such series call for intermittent-demand methods. Both tests choose ε with the rule of Comment 3, which therefore also demonstrates the rule on series not used to design it.")
    where(doc, "new Section 5.11 and Table 12; Section 5.14 (Summary and limitations); Supplementary S2.", RED)


def r1_c3(doc):
    comment(doc, *R1[3])
    label(doc, "Response")
    para(doc, "We agree and now provide (i) a result explaining what ε does to α, (ii) a concrete selection rule, and (iii) a quantitative sensitivity analysis of the interpretation.")
    para(doc, "**(i) Theory (new Proposition 4.3 and Remark 4.4).** For the shifted log-ratio")
    equation(doc, r"\rho_\varepsilon=\log(y_{t+1}+\varepsilon)-\log(y_t+\varepsilon),")
    para(doc, "we prove that, for every $\\varepsilon>0$,")
    equation(doc, r"\mathrm{sign}(\rho_\varepsilon)=\mathrm{sign}(y_{t+1}-y_t)")
    para(doc, "and")
    equation(doc, r"\frac{\partial\rho_\varepsilon}{\partial\varepsilon}=\frac{y_t-y_{t+1}}{(y_{t+1}+\varepsilon)(y_t+\varepsilon)} .")
    para(doc, "Hence $|\\rho_\\varepsilon|$ decreases strictly with ε: a larger shift moves α toward 1 but never changes its sign. Since $\\rho_\\varepsilon\\to\\log(y_{t+1}/y_t)$ as ε → 0 and $\\varepsilon\\rho_\\varepsilon\\to y_{t+1}-y_t$ as ε → ∞, the target passes continuously from multiplicative to additive. To first order the predicted change is")
    equation(doc, r"\hat{y}_{t+1}-y_t\approx(y_t+\varepsilon)\,\eta_t ,")
    para(doc, "i.e. proportional to the level when ε ≪ $y_t$ and level-independent when ε ≫ $y_t$.")
    para(doc, "**(ii) Rule for a new application (Section 5.13).** (1) Use a geometric grid from the measurement resolution up to about 0.2 × the median target; beyond that α no longer reads as a relative change. (2) Select ε on the validation split with the closed-form Ridge-α (seconds per grid point), using the criterion that matches the deployment metric. (3) Share the selected ε across backbones and report it together with any α values. Table 14 shows that the criterion matters exactly as the proposition predicts: on appliance energy, validation RMSE selects the largest ε and validation sMAPE the smallest.")
    para(doc, "**(iii) Sensitivity of the interpretation (Section 5.13, last paragraph).** Under a tenfold change of ε:")
    bullet(doc, "realised log-ratios keep their sign at 100% of test points and never grow in magnitude (also verified in Table 13);")
    bullet(doc, "fitted gates of all four backbones keep their rank order (Spearman 0.95–1.00) and their sign at 85–99% of points; the disagreements are near-identity gates (for Ridge- and GBM-α the median $|\\eta_t|$ among them is at most 0.03, a predicted change below 3%);")
    bullet(doc, "their spread shrinks by 6–29%, the attenuation predicted by the proposition.")
    para(doc, "Hence the direction and ordering of α are robust to ε, whereas its magnitude must be read at the reported ε. Accuracy is equally robust: across the whole grid, the test RMSE of Ridge-α varies by at most 1.5% and its sMAPE by at most 1%.")
    where(doc, "Proposition 4.3 and Remark 4.4; Remark 2.2; Section 5.13 (rule, Table 14, interpretation); Table 13; Supplementary S2.", RED)


def r1_c4(doc):
    comment(doc, *R1[4])
    label(doc, "Response")
    para(doc, "Agreed. Section 4 now contains only the results the experiments use, and the main text is three pages shorter (20 instead of 23 pages) despite the new tables.")
    bullet(doc, "**Moved to Supplementary S1:** the long proofs of Theorem 4.9 (recovery of the classical model) and Theorem 4.12 (universal approximation).")
    bullet(doc, "**Moved to Supplementary S1.1 as supporting results:** baseline containment, norm/Lipschitz control, exact gradients, and gate identifiability.")
    bullet(doc, "**Removed:** the ridge-uniqueness theorem (now one sentence after Eq. (8)) and the modality-ambiguity proposition.")
    bullet(doc, "**Condensed:** the two introductory paragraphs of Section 4 into one that separates the novel core from standard properties.")
    para(doc, "The only addition is the short Proposition 4.3 requested in Comment 3.")
    where(doc, "Section 4; Eq. (8); Supplementary S1 and S1.1.", RED)


def r1_c5(doc):
    comment(doc, *R1[5])
    label(doc, "Response")
    para(doc, "Thank you. The four recommendations correspond to Comments 1–4 and have all been implemented (focus: Comment 1; ε guidance: Comment 3; streamlined theory: Comment 4; harder data: Comment 2). We retained the balanced RMSE discussion and made it more precise: in accordance with Comment 3 of Reviewer 2, the paper now quantifies the peak (top-decile) penalty and shows how the composite objective already defined in Section 3 removes most of it (Section 5.5, Table 6).")


# ---------------- Reviewer 2 responses ----------------
def r2_c1(doc, combined):
    comment(doc, *R2[1])
    label(doc, "Response")
    if combined:
        para(doc, "We agree. This revision has been implemented in accordance with Comment 1 of Reviewer 1: all feature, spatial, multimodal, segmentation and medical-imaging material has been removed, and the paper now states that its theory and experiments concern positive-state forecasting only. The theory is no longer padded either (Comment 4 of Reviewer 1).")
        return
    para(doc, "We agree, and this material has been removed entirely (the same request was made by the other reviewer, and the change is shown in red in the manuscript). Removed are the feature-gate, spatial-map and modality-fusion operators (Section 2); the classification/segmentation losses and feature/spatial/modality penalties (Section 3); the modality part of the identifiability theorem and the modality-ambiguity proposition (Section 4); and the medical-imaging section (former Section 6). The Introduction now states that “both the theory and the experiments of this paper concern this setting only” (positive-state forecasting), and the operator is defined for scalar and vector positive states only (Definition 2.4).")
    para(doc, "The theoretical contribution is no longer padded: Section 4 keeps only the results the experiments use, routine proofs were moved to the Supplementary Material, and the main text is three pages shorter (20 instead of 23).")
    para(doc, "**Changes in the manuscript** (red text): Abstract; Sections 1–4, 6 and 7; Supplementary S1.", after=6)


def r2_c2(doc):
    comment(doc, *R2[2])
    label(doc, "Response")
    para(doc, "We agree that the protocol must be consistent, and the validation rule now governs all primary experiments. Every alpha model of Table 3 — Ridge, GBM, MLP (5 seeds) and LSTM (3 seeds) — was re-trained with the validation-selected $\\varepsilon^\\star$ (10, 1, 10), with all other settings and seeds unchanged (new Table 15):")
    table(doc, ["α better than the matched raw backbone", "a-priori ε₀", "validation-selected ε*"],
          [["RMSE", "8 / 12", "9 / 12"], ["MAE", "11 / 12", "12 / 12"], ["sMAPE", "12 / 12", "12 / 12"],
           ["max. change in test RMSE of an α model", "—", "2.5%"]])
    para(doc, "So the a-priori values were not favourable to the method; they were conservative. Every conclusion holds under both protocols, and the squared-error results slightly improve under the validation rule. We keep the a-priori values as the reported protocol for one methodological reason, now stated in Section 5.1: they are fixed before any data is seen, so the alpha models receive no tuned hyperparameter that the raw models (which have no ε) lack. Readers now see both protocols side by side.")
    para(doc, "The rule is also no longer post hoc: it is stated as the recommended procedure (Section 5.13), justified by the new Proposition 4.3 and applied to the new stress tests; this part is described in our response to Comment 3 of Reviewer 1. Finally, the choice matters little in practice: across the whole ε grid, the test RMSE of Ridge-α varies by at most 1.5% and its sMAPE by at most 1%, far less than the alpha-versus-raw gaps (Table 4).")
    where(doc, "Section 5.1 (protocol); Section 5.13 (paragraph “Validation-selected ε in all primary experiments” and Table 15); Supplementary S2–S3.", GREEN)


def r2_c3(doc):
    comment(doc, *R2[3])
    label(doc, "Response")
    para(doc, "We agree that “predictable” must not read as “harmless”. The text now presents it as a practical limitation (Section 5.5, new paragraph “Peaks: a practical limitation and its remedy”; Sections 5.3 and 5.14), and we quantified and addressed it:")
    bullet(doc, "**Quantified.** On the top decile of the test target, the alpha models of Table 3 have 1–17% higher RMSE than their raw counterparts and under-predict peaks more strongly in 11 of 12 backbone–dataset pairs.")
    bullet(doc, "**Addressed within the framework.** Section 3 already defines a composite objective, which we now evaluate:")
    equation(doc, r"\mathcal{L}_{\mathrm{long}}=\lambda_\rho\mathcal{L}_{\mathrm{ratio}}+\lambda_y\mathcal{L}_{\mathrm{state}}")
    para(doc, "with $\\lambda_\\rho=1/\\mathrm{Var}(\\rho)$ and $\\lambda_y=\\lambda/\\mathrm{Var}(y)$ estimated on the training data, so that a single dial λ trades relative accuracy for peak accuracy (MLP backbone, new Table 6):")
    table(doc, ["Top-decile RMSE (overall sMAPE)", "Beijing PM2.5", "Air quality", "Appliance energy"],
          [["MLP, raw target", "27.75 (21.5)", "4.74 (30.4)", "170.1 (27.4)"],
           ["MLP-α (λ = 0)", "30.44 (17.0)", "4.95 (22.5)", "172.4 (20.4)"],
           ["MLP-α, composite λ = 10", "28.36 (16.9)", "4.72 (24.0)", "169.4 (23.0)"]],
          bold_cells={(1, 1), (3, 2), (3, 3)})
    para(doc, "With λ = 10 the peak error matches the raw model on air quality and appliance energy and closes 77% of the gap on Beijing, while overall RMSE stays below the raw model and sMAPE stays 4–6 points lower on all three datasets. A larger shift acts in the same direction (Proposition 4.3): with the validation-selected ε the top-decile error falls in 10 of 12 pairs. The guidance is now explicit: the alpha target when proportional accuracy matters, the composite objective when peaks also matter.")
    where(doc, "Section 3 (role of $\\lambda_y$); Section 5.3; Section 5.5 (new paragraph and Table 6); Sections 5.14 and 7; Supplementary S2–S3.", GREEN)


def r2_c4(doc):
    comment(doc, *R2[4])
    label(doc, "Response")
    para(doc, "We added the two most widely used forecasters designed for skewed, heteroscedastic nonnegative data that need no target transform (Sections 5.2 and 5.8, Table 9): **LightGBM with a Tweedie objective** (compound Poisson–gamma, handles zeros and right skew) and **DeepAR** (Salinas et al., 2020) with its mean scaling and either its default Student-t likelihood or a Tweedie likelihood. Three findings answer the question directly:")
    bullet(doc, "**They are strong baselines,** as expected: each already builds in a relative scale (the log link of Tweedie; the division of DeepAR by the recent level).")
    bullet(doc, "**The alpha version of the same backbone remains better in relative error:** LightGBM-α beats LightGBM-Tweedie in sMAPE on all three datasets and in RMSE on two.")
    bullet(doc, "**The two ideas compose:** DeepAR-α — identical inputs and likelihood, alpha target — improves DeepAR on all three datasets in both RMSE and sMAPE, and gives the best sMAPE of the whole comparison on every dataset.")
    table(doc, ["RMSE / sMAPE (%)", "Beijing PM2.5", "Air quality", "Appliance energy"],
          [["LightGBM-Tweedie", "17.23 / 17.1", "2.56 / 23.2", "58.84 / 20.7"],
           ["LightGBM-α", "17.08 / 16.7", "2.58 / 22.0", "58.13 / 18.7"],
           ["DeepAR (Student-t)", "17.06 / 16.7", "2.67 / 23.2", "60.76 / 18.4"],
           ["DeepAR (Tweedie)", "17.23 / 17.4", "2.60 / 23.1", "59.73 / 21.0"],
           ["DeepAR-α (Student-t)", "16.96 / 16.4", "2.53 / 21.7", "60.43 / 18.1"]])
    para(doc, "The log-ratio target is therefore not a substitute for skew-aware modelling but a complementary inductive bias that improves even models built for this kind of data.")
    where(doc, "Section 5.2 (Models); Section 5.8 (new paragraph) and Table 9 (middle block); Section 7; Supplementary S2–S3.", GREEN)


def r2_c5(doc):
    comment(doc, *R2[5])
    label(doc, "Response")
    para(doc, "We thank the reviewer for this assessment. The results singled out — the shift-induced bias bound, the exact log-state/log-ratio loss equivalence and the contractive stability guarantee — are kept in the main text (Theorems 4.1, 4.7 and 4.16), and the bias bound is now complemented by Proposition 4.3 on how the shift shapes the gate. Routine proofs and supporting results were moved to the Supplementary Material (Comment 4 of Reviewer 1).")


def r2_c6(doc):
    comment(doc, *R2[6])
    label(doc, "Response")
    para(doc, "Both issues have been resolved: the scope inflation under Comment 1 above (all spatial, multimodal and imaging material removed), and the shift hyperparameter under Comment 2 above (every primary alpha model re-trained with the validation-selected ε; all conclusions hold).")


def r2_c7(doc):
    comment(doc, *R2[7])
    label(doc, "Response")
    para(doc, "This comment repeats Comment 4; the revision has been implemented as described in our response to Comment 4 of Reviewer 2 (LightGBM-Tweedie, DeepAR with Student-t and Tweedie likelihoods, and DeepAR-α; Table 9).")


def r2_c8(doc):
    comment(doc, *R2[8])
    label(doc, "Response")
    para(doc, "Thank you. The spatial and multimodal theory has been removed entirely (Comment 1 above). We are grateful for the positive assessment of the proofs and of the matched-ablation design, both of which are unchanged.")


INTRO = ("We thank the Editor and the reviewers for their constructive reports. Both reviewers recognise the soundness of the theory and of the matched-ablation design. Their requests were to focus the paper on what is validated, to settle the choice of the shift ε, to treat the peak-error trade-off as a practical limitation, and to compare against forecasters built for skewed positive data. We answered every point with new evidence while keeping the paper concise; the main text is now 20 pages instead of 23.")
SUMMARY = [
    "**Scope.** All feature, spatial, multimodal, segmentation and medical-imaging material has been removed; theory and experiments now concern positive-state forecasting only.",
    "**Theory.** Long proofs and supporting results were moved to the Supplementary Material; a new proposition shows that ε shrinks the gate toward one without changing its sign.",
    "**Shift ε.** A practical selection rule; every primary alpha model re-trained with the validation-selected ε (all conclusions hold); interpretation sensitivity quantified.",
    "**Peaks.** The top-decile penalty is quantified, and the composite objective already defined in the paper removes most of it.",
    "**Baselines and data.** LightGBM-Tweedie and DeepAR added (DeepAR-α improves DeepAR on all datasets); stress tests on covariate-free and intermittent series.",
]


def build(which):
    doc = new_doc()
    sub = {"all": "Response to the Reviewers' Comments", "r1": "Response to Reviewer 1", "r2": "Response to Reviewer 2"}[which]
    header(doc, sub)
    if which == "all":
        para(doc, "Dear Editor,")
        para(doc, INTRO)
        for s in SUMMARY:
            bullet(doc, s)
        para(doc, "In the revised manuscript and Supplementary Material, changes made in response to **Reviewer 1 are shown in red** and those made in response to **Reviewer 2 in green**. Where the two reviewers raised the same issue, it is answered once and cross-referenced. Section, theorem, table and equation numbers refer to the revised manuscript.", before=4)
    else:
        col = "red" if which == "r1" else "green"
        para(doc, "Dear Reviewer,")
        para(doc, INTRO.replace("We thank the Editor and the reviewers for their constructive reports. Both reviewers recognise", "We thank you for your constructive report. Both reviewers recognised"))
        para(doc, f"Changes made in response to your comments are shown in **{col}** in the revised manuscript and Supplementary Material (changes made for the other reviewer are shown in {'green' if col == 'red' else 'red'}). Section, theorem, table and equation numbers refer to the revised manuscript.")
    if which in ("all", "r1"):
        if which == "all":
            para(doc, "**Reviewer 1**", size=13, color=RED, before=12, after=4)
        for f in [r1_general, r1_c1, r1_c2, r1_c3, r1_c4, r1_c5]:
            f(doc)
    if which in ("all", "r2"):
        if which == "all":
            para(doc, "**Reviewer 2**", size=13, color=GREEN, before=14, after=4)
        r2_c1(doc, which == "all")
        for f in [r2_c2, r2_c3, r2_c4, r2_c5, r2_c6, r2_c7, r2_c8]:
            f(doc)
    para(doc, "We thank the reviewers again; their comments have made the paper more focused and its evidence more complete.", before=10)
    para(doc, "Sincerely,\nThe authors")
    name = {"all": "Response to Reviewers.docx", "r1": "Response to Reviewer 1.docx", "r2": "Response to Reviewer 2.docx"}[which]
    doc.save(os.path.join(OUT, name))
    return name


if __name__ == "__main__":
    for w in ["all", "r1", "r2"]:
        print("saved", build(w))
