"""Reviewer-requested extra experiments:
  (A) target-parameterization ablation  -> transform_<ds>.csv
      raw / logstate / log1p / boxcox / delta / alpha on a fixed MLP backbone,
      isolating whether the gain is from a log, a residual, or the shifted log-RATIO.
  (B) multi-loss Diebold-Mariano (sq/abs/sMAPE) for all FOUR backbones -> dmmulti_<ds>.csv
  (C) calibration: alpha-heteroscedastic vs raw-heteroscedastic vs split-conformal,
      scored by PICP/MPIW/Winkler/CRPS/NLL -> calib_<ds>.csv
"""
import os, sys, argparse, warnings
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, os.path.dirname(__file__))
import datasets as D
import models as M
import common as C

warnings.filterwarnings("ignore")
torch.set_num_threads(int(os.environ.get("ADN_THREADS", 2)))
RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(RES, exist_ok=True)
EPS = {"beijing": 1.0, "airq": 0.1, "energy": 1.0}
TRANSFORMS = ["raw", "logstate", "log1p", "boxcox", "delta", "alpha"]


def seed_mean(fn, seeds):
    ps = [fn(s) for s in seeds]
    return np.mean(ps, 0)


def run(ds, seeds_mlp=5, seeds_lstm=3):
    eps = EPS[ds]
    d = D.LOADERS[ds]()
    w = D.make_windows(d, L=24, horizon=12)
    sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
    yte, ate = w["ynext"][te], w["anchor"][te]
    yva, ava = w["ynext"][va], w["anchor"][va]
    smlp = list(range(seeds_mlp)); slstm = list(range(seeds_lstm))
    print(f"\n==== {ds} (eps={eps}) ====", flush=True)

    # ---------- (A) transform ablation + cache alpha test/val preds ----------
    rows, cache = [], {}
    for tf in TRANSFORMS:
        tests, vals = [], []
        for s in smlp:
            yhat, yval = M.mlp_transform_model(w, tr, va, te, transform=tf, eps=eps, seed=s)
            tests.append(yhat); vals.append(yval)
        ytest = np.mean(tests, 0); yvalm = np.mean(vals, 0)
        cache[tf] = (ytest, yvalm)
        m = C.all_metrics(yte, ytest, ate, eps); m["transform"] = tf
        rows.append(m)
    pd.DataFrame(rows)[["transform", "RMSE", "MAE", "sMAPE", "logRMSE"]].to_csv(
        os.path.join(RES, f"transform_{ds}.csv"), index=False)
    print("  [A] transform ablation done")

    # ---------- (B) multi-loss DM for four backbones ----------
    # raw & alpha point predictions per backbone (seed-avg for neural)
    pred = {}
    pred[("Ridge", "raw")] = M.ridge_raw(w, tr, te)
    pred[("Ridge", "alpha")] = M.ridge_logratio(w, tr, te, eps)[0]
    pred[("GBM", "raw")] = M.gbm_raw(w, tr, te)
    pred[("GBM", "alpha")] = M.gbm_logratio(w, tr, te, eps)
    pred[("MLP", "raw")] = cache["raw"][0]
    pred[("MLP", "alpha")] = cache["alpha"][0]
    pred[("LSTM", "raw")] = seed_mean(lambda s: M.lstm_model(w, tr, va, te, mode="raw", eps=eps, seed=s)[0], slstm)
    pred[("LSTM", "alpha")] = seed_mean(lambda s: M.lstm_model(w, tr, va, te, mode="alpha", eps=eps, seed=s)[0], slstm)
    dm_rows = []
    for bk in ["Ridge", "GBM", "MLP", "LSTM"]:
        fa, fr = pred[(bk, "alpha")], pred[(bk, "raw")]
        for loss in ["sq", "abs", "smape"]:
            dm, p = C.dm_from_losses(C.loss_vec(yte, fa, loss), C.loss_vec(yte, fr, loss))
            dm_rows.append(dict(backbone=bk, loss=loss, DM=dm, p_value=p,
                                favors=("alpha" if dm < 0 else "raw")))
    pd.DataFrame(dm_rows).to_csv(os.path.join(RES, f"dmmulti_{ds}.csv"), index=False)
    print("  [B] multi-loss DM done")

    # ---------- (C) calibration ----------
    # alpha-heteroscedastic: average predictive params over seeds
    emu, esig = [], []
    for s in smlp:
        _, _, aux = M.mlp_model(w, tr, va, te, mode="alpha", eps=eps, seed=s, hetero=True)
        emu.append(aux["eta_mu"]); esig.append(aux["eta_sigma"])
    eta_mu = np.mean(emu, 0); eta_sig = np.sqrt(np.mean(np.square(esig), 0))
    lo = (ate + eps) * np.exp(eta_mu - 1.96 * eta_sig) - eps
    hi = (ate + eps) * np.exp(eta_mu + 1.96 * eta_sig) - eps
    yhat_a = (ate + eps) * np.exp(eta_mu) - eps
    # sample-based CRPS for the lognormal-on-shifted-state predictive
    rng = np.random.default_rng(0)
    z = rng.standard_normal((len(yte), 200))
    samp = (ate[:, None] + eps) * np.exp(eta_mu[:, None] + eta_sig[:, None] * z) - eps
    eta_true = np.log(yte + eps) - np.log(ate + eps)
    nll_a = (C.nll_gaussian(eta_true, eta_mu, eta_sig) + float(np.mean(np.log(yte + eps))))
    cal = [dict(model="alpha-hetero", PICP=C.picp(yte, lo, hi), MPIW=C.mpiw(lo, hi),
                Winkler=C.winkler_score(yte, lo, hi), CRPS=C.crps_samples(yte, samp), NLL=nll_a)]

    # raw-heteroscedastic baseline
    rmu, rsig = [], []
    for s in smlp:
        _, mu_r, sig_r = M.mlp_raw_hetero(w, tr, va, te, seed=s)
        rmu.append(mu_r); rsig.append(sig_r)
    mu_r = np.mean(rmu, 0); sig_r = np.sqrt(np.mean(np.square(rsig), 0))
    lo_r, hi_r = mu_r - 1.96 * sig_r, mu_r + 1.96 * sig_r
    cal.append(dict(model="raw-hetero", PICP=C.picp(yte, lo_r, hi_r), MPIW=C.mpiw(lo_r, hi_r),
                    Winkler=C.winkler_score(yte, lo_r, hi_r),
                    CRPS=C.crps_gaussian(yte, mu_r, sig_r), NLL=C.nll_gaussian(yte, mu_r, sig_r)))

    # split-conformal around the MLP-alpha point prediction (val residuals)
    yval_alpha = cache["alpha"][1]
    res = np.abs(yva - yval_alpha)
    n = len(res); q_level = min(1.0, np.ceil((n + 1) * 0.95) / n)
    q = np.quantile(res, q_level)
    yhat_pt = cache["alpha"][0]
    lo_c, hi_c = yhat_pt - q, yhat_pt + q
    cal.append(dict(model="alpha-conformal", PICP=C.picp(yte, lo_c, hi_c), MPIW=C.mpiw(lo_c, hi_c),
                    Winkler=C.winkler_score(yte, lo_c, hi_c), CRPS=np.nan, NLL=np.nan))
    pd.DataFrame(cal).to_csv(os.path.join(RES, f"calib_{ds}.csv"), index=False)
    print("  [C] calibration done")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=["beijing", "airq", "energy"])
    ap.add_argument("--seeds_mlp", type=int, default=5)
    ap.add_argument("--seeds_lstm", type=int, default=3)
    args = ap.parse_args()
    for ds in args.datasets:
        run(ds, args.seeds_mlp, args.seeds_lstm)
