"""Additional experiments: eps protocol, peak-aware objective, skew-aware baselines,
stress tests.

Outputs (work/results):
  ncaa_main_<ds>.csv    four backbones raw / alpha(eps0) / alpha(eps_val) + composite
                        objective, with peak (top-decile) metrics
  ncaa_interp_<ds>.csv  sensitivity of the fitted gate to eps (rank corr., sign agreement)
  ncaa_epscrit_<ds>.csv eps selected under RMSE vs sMAPE validation criteria (ridge)
  ncaa_skew_<ds>.csv    LightGBM-Tweedie, DeepAR (Student-t), DeepAR-Tweedie
  ncaa_stress.csv       intermittent 'lights' series + covariate-free variants
"""
import os, sys, argparse, warnings, time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from scipy.stats import spearmanr

sys.path.insert(0, os.path.dirname(__file__))
import datasets as D
import models as M
import sota_models as S
import common as C

warnings.filterwarnings("ignore")
torch.set_num_threads(int(os.environ.get("ADN_THREADS", 2)))
RES = os.path.join(os.path.dirname(__file__), "..", "results")
EPS0 = {"beijing": 1.0, "airq": 0.1, "energy": 1.0}
GRID = np.array([0.01, 0.03, 0.1, 0.3, 1, 3, 10])


def eps_val_from_csv(ds):
    df = pd.read_csv(os.path.join(RES, f"eps_{ds}.csv"))
    return float(df.loc[df.val_RMSE.idxmin(), "eps"])


def peak(y, yhat, q=0.9):
    m = y >= np.quantile(y, q)
    return dict(peakRMSE=C.rmse(y[m], yhat[m]), peakBias=float(np.mean(yhat[m] - y[m])))


def metr(y, yhat, a, eps):
    m = C.all_metrics(y, yhat, a, eps); m.update(peak(y, yhat)); return m


def agg(name, rows, **extra):
    out = dict(model=name, **extra)
    for k in rows[0]:
        v = np.array([r[k] for r in rows], float)
        out[k] = float(v.mean()); out[k + "_std"] = float(v.std())
    return out


def eta_of(yhat, a, eps):
    return np.log(np.maximum(yhat + eps, 1e-12)) - np.log(a + eps)


# ------------------------- composite (peak-aware) objective -----------------
def mlp_composite(w, tr, va, te, *, eps, lam=1.0, seed=0):
    """Same MLP/optimizer/budget as MLP-alpha; loss = normalised log-ratio MSE
    + lam * normalised raw-scale MSE of yhat=(a+eps)exp(eta)-eps."""
    Xtr = torch.tensor(w["Xtab"][tr]).float(); Xva = torch.tensor(w["Xtab"][va]).float()
    Xte = torch.tensor(w["Xtab"][te]).float()
    y = np.concatenate([w["ynext"][tr], w["ynext"][va]]).astype(np.float32)
    a = np.concatenate([w["anchor"][tr], w["anchor"][va]]).astype(np.float32)
    rho = M.shifted_logratio(y, a, eps).astype(np.float32)
    ntr = tr.stop - tr.start
    s_rho = float(rho[:ntr].var()) + 1e-8; s_y = float(y[:ntr].var()) + 1e-8
    Y_t, A_t, R_t = torch.tensor(y), torch.tensor(a), torch.tensor(rho)

    def loss_fn(out, idx):
        i = idx[:, 0].long(); eta = out[:, 0]
        yhat = (A_t[i] + eps) * torch.exp(torch.clamp(eta, -8, 8)) - eps
        return ((eta - R_t[i]) ** 2).mean() / s_rho + lam * ((yhat - Y_t[i]) ** 2).mean() / s_y

    Itr = np.arange(ntr, dtype=np.float32); Iva = np.arange(ntr, len(y), dtype=np.float32)
    model = M.MLP(w["Xtab"].shape[1], out=1)
    model = M._train_torch(model, Xtr, Itr, Xva, Iva, loss_fn=loss_fn, seed=seed)
    model.eval()
    with torch.no_grad():
        eta = model(Xte).numpy()[:, 0]
    return M.invert_alpha(eta, w["anchor"][te], eps).astype(np.float32)


# ------------------------------ DeepAR-style --------------------------------
def deepar_alpha(w, tr, va, te, *, eps, seed=0):
    """DeepAR inputs/backbone with the alpha target: Student-t likelihood on the shifted
    log-ratio rho; point forecast (a+eps)exp(loc)-eps."""
    yw = w["Xseq_raw"][:, :, 0]
    nu = (1.0 + yw.mean(1)).astype(np.float32)
    xs = w["Xseq"].copy(); xs[:, :, 0] = yw / nu[:, None]
    lnu = np.log(nu); lnu = (lnu - lnu[tr].mean()) / (lnu[tr].std() + 1e-6)
    xc = np.concatenate([w["calnext"], lnu[:, None]], 1).astype(np.float32)
    Xs = torch.tensor(xs).float(); Xc = torch.tensor(xc).float()
    rho = M.shifted_logratio(w["ynext"], w["anchor"], eps).astype(np.float32)
    model = M.LSTMHead(w["n_cov"], xc.shape[1], hidden=64, out=3)

    def loss_fn(o, y):
        loc = o[:, :1]; sc = nn.functional.softplus(o[:, 1:2]) + 1e-3
        df = 2.0 + nn.functional.softplus(o[:, 2:3])
        return -torch.distributions.StudentT(df, loc, sc).log_prob(y).mean()

    model = M._train_torch(model, (Xs[tr], Xc[tr]), rho[tr], (Xs[va], Xc[va]), rho[va],
                           loss_fn=loss_fn, seq=True, seed=seed)
    model.eval()
    with torch.no_grad():
        o = model(Xs[te], Xc[te]).numpy()
    return M.invert_alpha(o[:, 0], w["anchor"][te], eps).astype(np.float32)


def run_extra(ds, what, sm=5, ss=3):
    t0 = time.time(); e0 = EPS0[ds]
    w = D.make_windows(D.LOADERS[ds](), L=24, horizon=12)
    sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
    y, a = w["ynext"][te], w["anchor"][te]; rows = []
    if what == "lambda":
        for lam in [3.0, 10.0]:
            r = [metr(y, mlp_composite(w, tr, va, te, eps=e0, lam=lam, seed=s), a, e0) for s in range(sm)]
            rows.append(agg(f"MLP-alpha-composite-lam{lam:g}", r, lam=lam))
            print(f"[{ds}] lambda {lam} {time.time()-t0:.0f}s", flush=True)
    else:
        r = [metr(y, deepar_alpha(w, tr, va, te, eps=e0, seed=s), a, e0) for s in range(ss)]
        rows.append(agg("DeepAR-StudentT-alpha", r))
        print(f"[{ds}] DeepAR-alpha {time.time()-t0:.0f}s", flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(RES, f"ncaa_{what}_{ds}.csv"), index=False)


def deepar(w, tr, va, te, *, lik="studentt", seed=0, p=1.5):
    """LSTM encoder with DeepAR mean scaling nu = 1 + mean(y window); scaled target
    channel + standardised covariates as inputs, log(nu) appended to the head.
    lik = 'studentt' (DeepAR default) or 'tweedie' (log link, zeros/skew)."""
    yw = w["Xseq_raw"][:, :, 0]
    nu = (1.0 + yw.mean(1)).astype(np.float32)
    xs = w["Xseq"].copy(); xs[:, :, 0] = yw / nu[:, None]
    lnu = np.log(nu); lnu = (lnu - lnu[tr].mean()) / (lnu[tr].std() + 1e-6)
    xc = np.concatenate([w["calnext"], lnu[:, None]], 1).astype(np.float32)
    Xs = torch.tensor(xs).float(); Xc = torch.tensor(xc).float()
    z = (w["ynext"] / nu).astype(np.float32)
    out = 3 if lik == "studentt" else 1
    model = M.LSTMHead(w["n_cov"], xc.shape[1], hidden=64, out=out)

    if lik == "studentt":
        def loss_fn(o, y):
            loc = o[:, :1]; sc = nn.functional.softplus(o[:, 1:2]) + 1e-3
            df = 2.0 + nn.functional.softplus(o[:, 2:3])
            return -torch.distributions.StudentT(df, loc, sc).log_prob(y).mean()
    else:
        def loss_fn(o, y):
            mu = torch.exp(torch.clamp(o[:, :1], -10, 10))
            return (-y * mu ** (1 - p) / (1 - p) + mu ** (2 - p) / (2 - p)).mean()

    model = M._train_torch(model, (Xs[tr], Xc[tr]), z[tr], (Xs[va], Xc[va]), z[va],
                           loss_fn=loss_fn, seq=True, seed=seed)
    model.eval()
    with torch.no_grad():
        o = model(Xs[te], Xc[te]).numpy()
    zhat = o[:, 0] if lik == "studentt" else np.exp(np.clip(o[:, 0], -10, 10))
    return (zhat * nu[te]).astype(np.float32)


def lgb_tweedie(w, tr, te, seed=0, p=1.5):
    import lightgbm as lgb
    m = lgb.LGBMRegressor(objective="tweedie", tweedie_variance_power=p, n_estimators=400,
                          learning_rate=0.05, num_leaves=31, subsample=0.8,
                          colsample_bytree=0.8, random_state=seed, verbose=-1)
    m.fit(w["Xtab"][tr], w["ynext"][tr])
    return np.asarray(m.predict(w["Xtab"][te]), np.float32)


# ------------------------------ main datasets -------------------------------
def run_main(ds, sm=5, sl=3):
    t0 = time.time()
    e0, ev = EPS0[ds], eps_val_from_csv(ds)
    w = D.make_windows(D.LOADERS[ds](), L=24, horizon=12)
    sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
    y, a = w["ynext"][te], w["anchor"][te]
    rows, eta = [], {}

    def single(name, yhat, eps, tag):
        rows.append(dict(model=name, eps=eps, protocol=tag, **metr(y, yhat, a, eps)))
        return yhat

    single("Ridge-raw", M.ridge_raw(w, tr, te), e0, "raw")
    for e, tag in [(e0, "eps0"), (ev, "eps_val")]:
        yh, _ = M.ridge_logratio(w, tr, te, e); single("Ridge-alpha", yh, e, tag)
        eta[("Ridge", tag)] = eta_of(yh, a, e)
    single("GBM-raw", M.gbm_raw(w, tr, te), e0, "raw")
    for e, tag in [(e0, "eps0"), (ev, "eps_val")]:
        yh = M.gbm_logratio(w, tr, te, e); single("GBM-alpha", yh, e, tag)
        eta[("GBM", tag)] = eta_of(yh, a, e)
    print(f"[{ds}] linear/tree done {time.time()-t0:.0f}s", flush=True)

    def multi(name, fn, seeds, eps, tag, key=None):
        r, P = [], []
        for s in range(seeds):
            yh = fn(s); P.append(yh); r.append(metr(y, yh, a, eps))
        rows.append(agg(name, r, eps=eps, protocol=tag))
        if key:
            eta[key] = eta_of(np.mean(P, 0), a, eps)

    multi("MLP-raw", lambda s: M.mlp_model(w, tr, va, te, mode="raw", eps=e0, seed=s)[0], sm, e0, "raw")
    for e, tag in [(e0, "eps0"), (ev, "eps_val")]:
        multi("MLP-alpha", lambda s: M.mlp_model(w, tr, va, te, mode="alpha", eps=e, seed=s)[0],
              sm, e, tag, key=("MLP", tag))
    multi("MLP-alpha-composite", lambda s: mlp_composite(w, tr, va, te, eps=e0, lam=1.0, seed=s),
          sm, e0, "eps0")
    print(f"[{ds}] MLP done {time.time()-t0:.0f}s", flush=True)
    multi("LSTM-raw", lambda s: M.lstm_model(w, tr, va, te, mode="raw", eps=e0, seed=s)[0], sl, e0, "raw")
    for e, tag in [(e0, "eps0"), (ev, "eps_val")]:
        multi("LSTM-alpha", lambda s: M.lstm_model(w, tr, va, te, mode="alpha", eps=e, seed=s)[0],
              sl, e, tag, key=("LSTM", tag))
    print(f"[{ds}] LSTM done {time.time()-t0:.0f}s", flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(RES, f"ncaa_main_{ds}.csv"), index=False)

    # gate sensitivity to eps: realised and fitted log-ratios at eps0 vs eps_val
    ir = []
    r0, rv = M.shifted_logratio(y, a, e0), M.shifted_logratio(y, a, ev)
    nz = (np.abs(r0) > 1e-12)
    ir.append(dict(series="realised", spearman=spearmanr(r0, rv)[0],
                   sign_agree=float(np.mean(np.sign(r0[nz]) == np.sign(rv[nz]))),
                   sd_ratio=float(rv.std() / r0.std())))
    for b in ["Ridge", "GBM", "MLP", "LSTM"]:
        g0, gv = eta[(b, "eps0")], eta[(b, "eps_val")]
        ir.append(dict(series=b, spearman=spearmanr(g0, gv)[0],
                       sign_agree=float(np.mean(np.sign(g0) == np.sign(gv))),
                       sd_ratio=float(gv.std() / g0.std())))
    pd.DataFrame(ir).assign(eps0=e0, eps_val=ev).to_csv(
        os.path.join(RES, f"ncaa_interp_{ds}.csv"), index=False)

    # eps selected under RMSE vs sMAPE validation criteria (closed-form ridge)
    yv, av = w["ynext"][va], w["anchor"][va]
    cr = []
    for e in GRID * e0:
        yh, _ = M.ridge_logratio(w, tr, va, e)
        cr.append(dict(eps=e, eps_over_median=e / float(np.median(w["ynext"])),
                       val_RMSE=C.rmse(yv, yh), val_sMAPE=C.smape(yv, yh)))
    pd.DataFrame(cr).to_csv(os.path.join(RES, f"ncaa_epscrit_{ds}.csv"), index=False)
    print(f"[{ds}] main done {time.time()-t0:.0f}s", flush=True)


def run_skew(ds, seeds=3):
    t0 = time.time(); e0 = EPS0[ds]
    w = D.make_windows(D.LOADERS[ds](), L=24, horizon=12)
    sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
    y, a = w["ynext"][te], w["anchor"][te]; rows = []
    cands = {
        "LightGBM-raw": lambda s: S.tree_model("lightgbm", w, tr, te, mode="raw", eps=e0, seed=s),
        "LightGBM-alpha": lambda s: S.tree_model("lightgbm", w, tr, te, mode="alpha", eps=e0, seed=s),
        "LightGBM-Tweedie": lambda s: lgb_tweedie(w, tr, te, seed=s),
        "DeepAR-StudentT": lambda s: deepar(w, tr, va, te, lik="studentt", seed=s),
        "DeepAR-Tweedie": lambda s: deepar(w, tr, va, te, lik="tweedie", seed=s),
    }
    for name, fn in cands.items():
        r = [metr(y, fn(s), a, e0) for s in range(seeds)]
        rows.append(agg(name, r)); print(f"[{ds}] {name} {time.time()-t0:.0f}s", flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(RES, f"ncaa_skew_{ds}.csv"), index=False)


# ------------------------------- stress tests -------------------------------
def load_lights():
    df = pd.read_csv(os.path.join(D.DATA, "energy_appliances.csv"))
    df["ts"] = pd.to_datetime(df["date"]); df = df.sort_values("ts").reset_index(drop=True)
    cov = df[["Appliances", "T_out", "RH_out", "Press_mm_hg", "Windspeed", "Visibility",
              "Tdewpoint"]].astype(float).interpolate(limit=6).ffill().bfill()
    hs, hc = D._cyc(df["ts"].dt.hour.values, 24); ws, wc = D._cyc(df["ts"].dt.dayofweek.values, 7)
    cal = np.stack([hs, hc, ws, wc], 1)
    y = df["lights"].astype(float).values
    return D._assemble(df["ts"].values, y, cov.values, cal, list(cov.columns),
                       ["hr_s", "hr_c", "dw_s", "dw_c"], np.isfinite(y),
                       name="lights", target="Lights energy (Wh)", period=144)


def univariate(ds):
    d = D.LOADERS[ds](); d = dict(d); d["cov"] = d["cov"][:, :0]; d["cov_names"] = []
    d["name"] = ds + "-univariate"; return d


def run_stress(sm=5):
    cases = [("lights", load_lights(), 10.0)] + [(ds + "-univariate", univariate(ds), EPS0[ds])
                                                for ds in ["beijing", "airq", "energy"]]
    rows = []
    for name, d, eref in cases:
        t0 = time.time()
        w = D.make_windows(d, L=24, horizon=12)
        sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
        y, a, yv = w["ynext"][te], w["anchor"][te], w["ynext"][va]
        # eps rule: grid around the reference scale, selected by validation RMSE of ridge-alpha
        grid = GRID * eref
        vr = [C.rmse(yv, M.ridge_logratio(w, tr, va, e)[0]) for e in grid]
        e = float(grid[int(np.argmin(vr))])
        zeros = float(np.mean(w["ynext"] == 0))
        base = dict(case=name, eps=e, zero_frac=zeros)
        rows.append(dict(model="Persistence", **base, **metr(y, a.copy(), a, e)))
        rows.append(dict(model="Ridge-raw", **base, **metr(y, M.ridge_raw(w, tr, te), a, e)))
        rows.append(dict(model="Ridge-alpha", **base, **metr(y, M.ridge_logratio(w, tr, te, e)[0], a, e)))
        rows.append(dict(model="GBM-raw", **base, **metr(y, M.gbm_raw(w, tr, te), a, e)))
        rows.append(dict(model="GBM-alpha", **base, **metr(y, M.gbm_logratio(w, tr, te, e), a, e)))
        for mode in ["raw", "alpha"]:
            r = [metr(y, M.mlp_model(w, tr, va, te, mode=mode, eps=e, seed=s)[0], a, e) for s in range(sm)]
            rr = agg(f"MLP-{mode}", r); rr.update(base); rows.append(rr)
        print(f"[stress {name}] eps={e:g} zeros={zeros:.2f} {time.time()-t0:.0f}s", flush=True)
        pd.DataFrame(rows).to_csv(os.path.join(RES, "ncaa_stress.csv"), index=False)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=["beijing", "airq", "energy"])
    ap.add_argument("--only", nargs="+", default=["main", "skew", "stress"])
    ap.add_argument("--seeds_mlp", type=int, default=5)
    ap.add_argument("--seeds_lstm", type=int, default=3)
    ap.add_argument("--seeds_skew", type=int, default=3)
    args = ap.parse_args()
    for ds in args.datasets:
        if "main" in args.only: run_main(ds, args.seeds_mlp, args.seeds_lstm)
        if "skew" in args.only: run_skew(ds, args.seeds_skew)
        if "lambda" in args.only: run_extra(ds, "lambda", args.seeds_mlp)
        if "deeparalpha" in args.only: run_extra(ds, "deeparalpha", ss=args.seeds_skew)
    if "stress" in args.only: run_stress(args.seeds_mlp)
