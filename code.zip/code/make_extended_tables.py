﻿"""LaTeX fragments for the additional experiments (run_extended.py outputs)."""
import os, sys
import numpy as np
import pandas as pd

RES = os.path.join(os.path.dirname(__file__), "..", "results")
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(RES, "..", "tables_extended")
os.makedirs(OUT, exist_ok=True)
DS = [("beijing", "Beijing PM2.5"), ("airq", "Air Quality (C$_6$H$_6$)"), ("energy", "Appliance Energy")]
BK = [("Ridge", "Ridge-Raw", "Ridge-Alpha(Thm5)"), ("GBM", "GBM-Raw", "GBM-Alpha"),
      ("MLP", "MLP-Raw", "MLP-Alpha"), ("LSTM", "LSTM-Raw", "LSTM-Alpha")]
r = lambda df, m, col: float(df.loc[df.model == m, col].iloc[0])


def bold(vals, fmt):
    shown = [fmt.format(v) for v in vals]; best = min(float(x) for x in shown)
    return [("\\textbf{" + x + "}") if float(x) == best else x for x in shown]


# ---------------- Table: alpha models at eps0 vs validation-selected eps -------------
lines = [r"\begin{tabular}{llcccccc}", r"\toprule",
         r" & & \multicolumn{3}{c}{RMSE} & \multicolumn{3}{c}{sMAPE (\%)} \\",
         r"\cmidrule(lr){3-5}\cmidrule(lr){6-8}",
         r"Dataset & Backbone & raw & $\alpha$ ($\eps_0$) & $\alpha$ ($\eps^\star$) & raw & $\alpha$ ($\eps_0$) & $\alpha$ ($\eps^\star$) \\",
         r"\midrule"]
wins = {"RMSE": [0, 0], "MAE": [0, 0], "sMAPE": [0, 0]}; dmax = 0.0
for ds, nm in DS:
    f = pd.read_csv(os.path.join(RES, f"forecast_{ds}.csv"))
    n = pd.read_csv(os.path.join(RES, f"ext_main_{ds}.csv"))
    ev = float(n.loc[n.protocol == "eps_val", "eps"].iloc[0])
    for i, (b, raw, al) in enumerate(BK):
        vv = {}
        for met in ["RMSE", "MAE", "sMAPE"]:
            x0, x1 = r(f, raw, met), r(f, al, met)
            x2 = float(n.loc[(n.model == f"{b}-alpha") & (n.protocol == "eps_val"), met].iloc[0])
            wins[met][0] += x1 < x0; wins[met][1] += x2 < x0; vv[met] = (x0, x1, x2)
            if met == "RMSE": dmax = max(dmax, abs(x2 - x1) / x1)
        fmt = "{:.2f}"
        lab = (r"\multirow{4}{*}{" + nm + f" ($\\eps^\\star={ev:g}$)" + "}") if i == 0 else ""
        lines.append(f"{lab} & {b} & " + " & ".join(bold(vv["RMSE"], fmt)) + " & " +
                     " & ".join(bold(vv["sMAPE"], "{:.1f}")) + r" \\")
    lines.append(r"\addlinespace[2pt]")
lines[-1] = r"\midrule"
lines.append(r"\multicolumn{2}{l}{$\alpha$ better than raw} & & %d/12 & %d/12 & & %d/12 & %d/12 \\"
             % (wins["RMSE"][0], wins["RMSE"][1], wins["sMAPE"][0], wins["sMAPE"][1]))
lines += [r"\bottomrule", r"\end{tabular}"]
open(os.path.join(OUT, "eps_robust.tex"), "w").write("\n".join(lines) + "\n")
print("eps wins", wins, "max rel RMSE change", round(dmax, 4))

# ---------------- Table: eps selection (RMSE vs sMAPE criterion) ---------------------
lines = [r"\begin{tabular}{lccccc}", r"\toprule",
         r"Dataset & $\eps_0$ (a priori) & $\eps^\star$ (val.\ RMSE) & $\eps^\star/\text{median}$ & $\eps^\star$ (val.\ sMAPE) & test RMSE / sMAPE at $\eps^\star$ \\",
         r"\midrule"]
E0 = {"beijing": 1.0, "airq": 0.1, "energy": 1.0}
for ds, nm in DS:
    c = pd.read_csv(os.path.join(RES, f"ext_epscrit_{ds}.csv"))
    e = pd.read_csv(os.path.join(RES, f"eps_{ds}.csv")); b = e.loc[e.val_RMSE.idxmin()]
    es = float(c.loc[c.val_sMAPE.idxmin(), "eps"])
    lines.append(f"{nm} & {E0[ds]:g} & {b.eps:g} & {b.eps_over_median:.3f} & {es:g} & "
                 f"{b.test_RMSE:.2f} / {b.test_sMAPE:.1f} \\\\")
lines += [r"\bottomrule", r"\end{tabular}"]
open(os.path.join(OUT, "eps_selection.tex"), "w").write("\n".join(lines) + "\n")

# ---------------- Table: peak-aware composite objective (MLP) ------------------------
rows = [("MLP (raw)", "MLP-raw", None), (r"MLP-$\alpha$, $\lambda=0$", "MLP-alpha", None),
        (r"composite, $\lambda=1$", "MLP-alpha-composite", None),
        (r"composite, $\lambda=3$", "MLP-alpha-composite-lam3", "lambda"),
        (r"composite, $\lambda=10$", "MLP-alpha-composite-lam10", "lambda")]
lines = [r"\begin{tabular}{lccccccccc}", r"\toprule",
         r" & \multicolumn{3}{c}{Beijing PM2.5} & \multicolumn{3}{c}{Air Quality (C$_6$H$_6$)} & \multicolumn{3}{c}{Appliance Energy} \\",
         r"\cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(lr){8-10}",
         r"Objective & RMSE & sMAPE & peak & RMSE & sMAPE & peak & RMSE & sMAPE & peak \\", r"\midrule"]
tab = {}
for ds, _ in DS:
    n = pd.read_csv(os.path.join(RES, f"ext_main_{ds}.csv")); n = n[n.protocol != "eps_val"]
    l = pd.read_csv(os.path.join(RES, f"ext_lambda_{ds}.csv"))
    for lab, m, src in rows:
        d = l if src else n
        tab[(ds, lab)] = [r(d, m, "RMSE"), r(d, m, "sMAPE"), r(d, m, "peakRMSE")]
cells = {}
for ds, _ in DS:
    for j, fmt in enumerate(["{:.2f}", "{:.1f}", "{:.2f}" if ds != "energy" else "{:.1f}"]):
        col = bold([tab[(ds, lab)][j] for lab, _, _ in rows], fmt)
        for k, (lab, _, _) in enumerate(rows):
            cells[(ds, lab, j)] = col[k]
for lab, _, _ in rows:
    lines.append(lab + " & " + " & ".join(cells[(ds, lab, j)] for ds, _ in DS for j in range(3)) + r" \\")
    if lab.startswith(r"MLP-$\alpha$"): lines.append(r"\addlinespace[1pt]")
lines += [r"\bottomrule", r"\end{tabular}"]
open(os.path.join(OUT, "peak.tex"), "w").write("\n".join(lines) + "\n")

# ---------------- Table: stress tests -------------------------------------------------
s = pd.read_csv(os.path.join(RES, "ext_stress.csv"))
cases = [("lights", "Intermittent lights"), ("beijing-univariate", "Beijing, no covariates"),
         ("airq-univariate", "Air quality, no covariates"), ("energy-univariate", "Energy, no covariates")]
lines = [r"\begin{tabular}{llccccccc}", r"\toprule",
         r" & & & \multicolumn{2}{c}{Ridge} & \multicolumn{2}{c}{GBM} & \multicolumn{2}{c}{MLP} \\",
         r"\cmidrule(lr){4-5}\cmidrule(lr){6-7}\cmidrule(lr){8-9}",
         r"Series (zeros, $\eps^\star$) & Metric & Persist. & raw & $\alpha$ & raw & $\alpha$ & raw & $\alpha$ \\",
         r"\midrule"]
for cs, nm in cases:
    d = s[s.case == cs]; z = float(d.zero_frac.iloc[0]); e = float(d.eps.iloc[0])
    mets = ["RMSE", "MAE"] if cs == "lights" else ["RMSE", "MAE", "sMAPE"]
    for i, met in enumerate(mets):
        fmt = "{:.1f}" if met == "sMAPE" else ("{:.2f}" if cs != "energy-univariate" else "{:.1f}")
        vals = [r(d, "Persistence", met)]
        cellv = [fmt.format(vals[0])]
        for b in ["Ridge", "GBM", "MLP"]:
            x0, x1 = r(d, f"{b}-raw", met), r(d, f"{b}-alpha", met)
            a0, a1 = fmt.format(x0), fmt.format(x1)
            cellv += [a0, ("\\textbf{" + a1 + "}") if float(a1) < float(a0) else a1]
        lab = (r"\multirow{%d}{*}{%s (%d\%%, %g)}" % (len(mets), nm, round(100 * z), e)) if i == 0 else ""
        mname = {"sMAPE": r"sMAPE (\%)"}.get(met, met)
        lines.append(f"{lab} & {mname} & " + " & ".join(cellv) + r" \\")
    lines.append(r"\addlinespace[2pt]")
lines[-1] = r"\bottomrule"; lines.append(r"\end{tabular}")
open(os.path.join(OUT, "stress.tex"), "w").write("\n".join(lines) + "\n")

# ---------------- skew-aware rows for the SOTA table ----------------------------------
out = {}
for ds, _ in DS:
    k = pd.read_csv(os.path.join(RES, f"ext_skew_{ds}.csv"))
    p = os.path.join(RES, f"ext_deeparalpha_{ds}.csv")
    if os.path.exists(p): k = pd.concat([k, pd.read_csv(p)])
    out[ds] = k
names = [("LightGBM-Tweedie", "LightGBM-Tweedie"), ("DeepAR (Student-$t$)", "DeepAR-StudentT"),
         ("DeepAR (Tweedie)", "DeepAR-Tweedie"), (r"DeepAR-$\alpha$ (Student-$t$)", "DeepAR-StudentT-alpha")]
sk = []
for lab, m in names:
    c = []
    for ds, _ in DS:
        d = out[ds]
        if (d.model == m).any():
            c += [f"{r(d, m, 'RMSE'):.2f}", f"{r(d, m, 'sMAPE'):.1f}"]
        else:
            c += ["--", "--"]
    sk.append(lab + " & " + " & ".join(c) + r" \\")
open(os.path.join(OUT, "sota_skew_rows.tex"), "w").write("\n".join(sk) + "\n")
for ds, _ in DS:
    print(ds); print(out[ds][["model", "RMSE", "MAE", "sMAPE", "peakRMSE"]].round(3).to_string(index=False))


