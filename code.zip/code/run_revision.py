"""Revision experiments addressing the five reviewers.

Outputs (work/results):
  sota_<ds>.csv       stronger/SOTA baselines: LightGBM, XGBoost, TCN, Transformer,
                      N-BEATS (raw vs alpha) + GLM families (Tweedie/Gamma/Poisson/
                      lognormal/quantile). [R1.7, R2.3, R4.5, R5.3]
  multistep_<ds>.csv  direct k-step forecasting, k in {1,3,6,12}, MLP raw vs alpha. [R2.4,R3.2]
  window_<ds>.csv     window-length robustness L in {12,24,48}, MLP raw vs alpha. [R4.7,R5.8]
  eps_<ds>.csv        eps sensitivity on every dataset + validation-based selection. [R1.8,R3.3,R5.5]
"""
import os, sys, argparse, warnings, copy
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, os.path.dirname(__file__))
import datasets as D
import models as M
import sota_models as S
import common as C

warnings.filterwarnings("ignore")
torch.set_num_threads(int(os.environ.get("ADN_THREADS", 2)))
RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(RES, exist_ok=True)
EPS = {"beijing": 1.0, "airq": 0.1, "energy": 1.0}


def metrics_row(name, yte, yhat, ate, eps, extra=None):
    m = C.all_metrics(yte, yhat, ate, eps); m["model"] = name
    if extra:
        m.update(extra)
    return m


def smean(fn, seeds):
    return np.mean([fn(s) for s in seeds], 0)


# ---------------- E4+E5: stronger / SOTA baselines (one-step) --------------
def run_sota(ds, seeds=3):
    eps = EPS[ds]; d = D.LOADERS[ds](); w = D.make_windows(d, L=24, horizon=12)
    sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
    yte, ate = w["ynext"][te], w["anchor"][te]
    sd = list(range(seeds)); rows = []
    # tree ensembles (raw + alpha)
    for k in ["lightgbm", "xgboost"]:
        for mode in ["raw", "alpha"]:
            yhat = smean(lambda s: S.tree_model(k, w, tr, te, mode=mode, eps=eps, seed=s), sd)
            rows.append(metrics_row(f"{k}-{mode}", yte, yhat, ate, eps))
    # SOTA neural (raw + alpha)
    for k in ["tcn", "transformer", "nbeats"]:
        for mode in ["raw", "alpha"]:
            yhat = smean(lambda s: S.seq_backbone(k, w, tr, va, te, mode=mode, eps=eps, seed=s), sd)
            rows.append(metrics_row(f"{k}-{mode}", yte, yhat, ate, eps))
    # GLM families (raw-target baselines)
    for g in ["tweedie", "gamma", "poisson", "lognormal", "quantile"]:
        try:
            yhat = S.glm_model(g, w, tr, te, eps=eps)
            rows.append(metrics_row(f"glm-{g}", yte, yhat, ate, eps))
        except Exception as e:
            print(f"  glm {g} failed: {e}")
    pd.DataFrame(rows).to_csv(os.path.join(RES, f"sota_{ds}.csv"), index=False)
    print(f"[{ds}] sota/baselines done ({len(rows)} models)")


# ---------------- E1: direct multi-step forecasting -----------------------
def run_multistep(ds, seeds=3):
    eps = EPS[ds]; d = D.LOADERS[ds](); w = D.make_windows(d, L=24, horizon=12)
    sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
    ate = w["anchor"][te]; sd = list(range(seeds)); rows = []
    for k in [1, 3, 6, 12]:
        wk = dict(w); wk["ynext"] = w["fut_y"][:, k - 1]        # k-step target, same base features
        yte = wk["ynext"][te]
        for mode in ["raw", "alpha"]:
            yhat = smean(lambda s: M.mlp_model(wk, tr, va, te, mode=mode, eps=eps, seed=s)[0], sd)
            m = C.all_metrics(yte, yhat, ate, eps); m.update(dict(model=f"MLP-{mode}", k=k))
            rows.append(m)
    pd.DataFrame(rows).to_csv(os.path.join(RES, f"multistep_{ds}.csv"), index=False)
    print(f"[{ds}] multistep done")


# ---------------- E2: window-length robustness ----------------------------
def run_window(ds, seeds=3):
    eps = EPS[ds]; d = D.LOADERS[ds](); sd = list(range(seeds)); rows = []
    for L in [12, 24, 48]:
        w = D.make_windows(d, L=L, horizon=12)
        sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
        yte, ate = w["ynext"][te], w["anchor"][te]
        for mode in ["raw", "alpha"]:
            yhat = smean(lambda s: M.mlp_model(w, tr, va, te, mode=mode, eps=eps, seed=s)[0], sd)
            m = C.all_metrics(yte, yhat, ate, eps); m.update(dict(model=f"MLP-{mode}", L=L))
            rows.append(m)
    pd.DataFrame(rows).to_csv(os.path.join(RES, f"window_{ds}.csv"), index=False)
    print(f"[{ds}] window-length done")


# ---------------- E3: eps sensitivity + validation selection --------------
def run_eps(ds):
    eps0 = EPS[ds]; d = D.LOADERS[ds](); w = D.make_windows(d, L=24, horizon=12)
    sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
    yte, ate = w["ynext"][te], w["anchor"][te]
    yva, ava = w["ynext"][va], w["anchor"][va]
    med = float(np.median(w["ynext"]))
    epss = np.unique(np.concatenate([np.array([0.01, 0.03, 0.1, 0.3, 1, 3, 10]) * eps0,
                                     [eps0]]))
    rows = []
    for e in epss:
        yhat, _ = M.ridge_logratio(w, tr, te, e)
        yhatv, _ = M.ridge_logratio(w, tr, va, e)
        rows.append(dict(eps=float(e), eps_over_median=float(e / med),
                         val_RMSE=C.rmse(yva, yhatv),
                         test_RMSE=C.rmse(yte, yhat),
                         test_sMAPE=C.smape(yte, yhat),
                         test_logRMSE=C.logratio_rmse(yte, yhat, ate, e)))
    df = pd.DataFrame(rows)
    best = df.loc[df.val_RMSE.idxmin()]     # validation-selected eps
    df["val_selected"] = (df.eps == best.eps)
    df.to_csv(os.path.join(RES, f"eps_{ds}.csv"), index=False)
    print(f"[{ds}] eps sweep done; val-selected eps={best.eps:g} "
          f"(test RMSE {best.test_RMSE:.3f})")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=["beijing", "airq", "energy"])
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--only", nargs="+", default=["sota", "multistep", "window", "eps"])
    args = ap.parse_args()
    for ds in args.datasets:
        if "eps" in args.only: run_eps(ds)
        if "window" in args.only: run_window(ds, args.seeds)
        if "multistep" in args.only: run_multistep(ds, args.seeds)
        if "sota" in args.only: run_sota(ds, args.seeds)
