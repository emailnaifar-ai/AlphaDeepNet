"""Controlled experiments that empirically verify the manuscript's theorems.

Produces vector figures (work/figs/*.pdf) and CSV tables (work/results/*.csv):
  T1  shift-induced log-ratio bias bound        (Theorem: shift bias)
  T2  classical power-law alpha recovery         (Theorem: recovery) + Lemma 1
  T3  multi-step relative-error envelope         (Theorem: multi-step)
  T4  gate non-identifiability + log-centering   (Theorem 14 + Corollary)
  T5  sensitivity to the shift eps on real data  (reviewer request 4.8)
"""
import os, sys, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(__file__))
FIG = os.path.join(os.path.dirname(__file__), "..", "figs")
RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(FIG, exist_ok=True); os.makedirs(RES, exist_ok=True)
rng = np.random.default_rng(0)
plt.rcParams.update({"font.size": 11, "figure.dpi": 120})


# ---------------- T1: shift-induced bias bound ----------------------------
def t1_shift_bias():
    pairs = [(5.0, 25.0), (50.0, 30.0), (2.0, 100.0)]
    eps = np.logspace(-3, 1.3, 60)
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    rows = []
    for (yt, yt1) in pairs:
        B = np.log((yt1 + eps) / (yt + eps)) - np.log(yt1 / yt)
        bound = eps * abs(1 / yt1 - 1 / yt)
        ax.plot(eps, np.abs(B), lw=2, label=fr"$|B_\varepsilon|$, $(y_t,y_{{t+1}})=({yt:.0f},{yt1:.0f})$")
        ax.plot(eps, bound, "--", lw=1.4, color=ax.lines[-1].get_color(), alpha=0.7)
        rows.append(dict(y_t=yt, y_t1=yt1, max_violation=float(np.max(np.abs(B) - bound))))
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"shift $\varepsilon$"); ax.set_ylabel(r"log-ratio distortion")
    ax.legend(fontsize=8, loc="lower right"); fig.tight_layout()
    fig.savefig(os.path.join(FIG, "T1_shift_bias.pdf")); plt.close(fig)
    pd.DataFrame(rows).to_csv(os.path.join(RES, "theory_T1_shift_bias.csv"), index=False)
    print("T1 max(|B|-bound) over all pairs/eps =",
          max(r["max_violation"] for r in rows), "(<=0 means bound holds)")


# ---------------- T2: classical recovery + Lemma 1 ------------------------
def t2_recovery():
    N, p = 4000, 3
    a, zeta, gamma = 0.3, 2.0, np.array([0.4, -0.3, 0.5])
    y = np.exp(rng.normal(0, 0.6, N)) + 0.5
    V = np.exp(rng.normal(0, 0.5, (N, p)))           # positive covariates
    eps = 1e-3
    logm = (gamma * np.log(V)).sum(1)
    m = np.exp(logm)

    # (a) exact recovery when b0 = 0  (log-linear is exact)
    rho0 = a * np.log(y + eps) - zeta * logm + rng.normal(0, 1e-3, N)
    Xlin = np.column_stack([np.ones(N), np.log(y + eps), np.log(V)])
    beta, *_ = np.linalg.lstsq(Xlin, rho0, rcond=None)
    pred0 = Xlin @ beta
    r2_0 = 1 - np.var(rho0 - pred0) / np.var(rho0)
    recov = dict(a_true=a, a_hat=float(beta[1]),
                 b1_true=float(-zeta * gamma[0]), b1_hat=float(beta[2]),
                 b2_true=float(-zeta * gamma[1]), b2_hat=float(beta[3]),
                 b3_true=float(-zeta * gamma[2]), b3_hat=float(beta[4]), R2=float(r2_0))
    pd.DataFrame([recov]).to_csv(os.path.join(RES, "theory_T2_recovery_b0eq0.csv"), index=False)

    # (b) b0>0: log-linear (approx) vs +nonlinear feature log(b0+m) (exact)
    rows = []
    for b0 in [0.0, 0.1, 0.5, 1.0, 2.0, 5.0]:
        rho = a * np.log(y + eps) - zeta * np.log(b0 + m)
        # log-linear module (no nonlinear denominator feature)
        blin, *_ = np.linalg.lstsq(Xlin, rho, rcond=None)
        r2_lin = 1 - np.var(rho - Xlin @ blin) / np.var(rho)
        # nonlinear module: add the exact log-denominator feature
        Xnl = np.column_stack([Xlin, np.log(b0 + m)])
        bnl, *_ = np.linalg.lstsq(Xnl, rho, rcond=None)
        r2_nl = 1 - np.var(rho - Xnl @ bnl) / np.var(rho)
        rows.append(dict(b0=b0, mean_mu=float(np.mean(b0 / m)),
                         R2_loglinear=float(r2_lin), R2_nonlinear=float(r2_nl)))
    pd.DataFrame(rows).to_csv(os.path.join(RES, "theory_T2_recovery_b0pos.csv"), index=False)

    # (c) Lemma 1 remainder bound:  |R(mu)| <= |zeta| mu^2 / (2(1-r)^2)
    r = 0.6
    mu = np.linspace(0, r, 200)
    actual = np.abs(-zeta * (np.log(1 + mu) - mu))
    bound = abs(zeta) * mu ** 2 / (2 * (1 - r) ** 2)
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    ax.plot(mu, actual, lw=2, label=r"actual $|R_t|=|\zeta||\log(1+\mu)-\mu|$")
    ax.plot(mu, bound, "--", lw=1.6, label=r"Lemma-1 bound $\frac{|\zeta|\mu^2}{2(1-r)^2}$")
    ax.set_xlabel(r"$\mu=b_0/m$"); ax.set_ylabel("log-alpha remainder")
    ax.legend(fontsize=9); fig.tight_layout()
    fig.savefig(os.path.join(FIG, "T2_lemma1_bound.pdf")); plt.close(fig)
    print(f"T2 recovery (b0=0): R2={r2_0:.6f}, a_hat={beta[1]:.4f} (true {a}); "
          f"Lemma1 max(actual-bound)={float(np.max(actual-bound)):.2e} (<=0 ok)")
    return recov, rows


# ---------------- T3: multi-step error envelope ---------------------------
def t3_multistep():
    K, trials = 24, 5000
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    rows = []
    for delta in [0.02, 0.05, 0.10]:
        u = rng.uniform(-delta, delta, (trials, K))     # |eta_hat-eta*| <= delta
        cum = np.cumsum(u, axis=1)
        rel = np.abs(np.exp(cum) - 1.0)
        emp = rel.max(0)
        env = np.exp(delta * np.arange(1, K + 1)) - 1.0
        ax.plot(np.arange(1, K + 1), emp, lw=2, label=fr"empirical max, $\delta={delta}$")
        ax.plot(np.arange(1, K + 1), env, "--", color=ax.lines[-1].get_color(), alpha=0.7)
        rows.append(dict(delta=delta, max_violation=float(np.max(emp - env))))
    ax.set_xlabel("horizon $k$"); ax.set_ylabel(r"relative shifted error")
    ax.legend(fontsize=9); fig.tight_layout()
    fig.savefig(os.path.join(FIG, "T3_multistep_envelope.pdf")); plt.close(fig)
    pd.DataFrame(rows).to_csv(os.path.join(RES, "theory_T3_multistep.csv"), index=False)
    print("T3 max(empirical-envelope) =", max(r["max_violation"] for r in rows),
          "(<=0 means envelope holds)")


# ---------------- T4: gate non-identifiability + log-centering ------------
def t4_identifiability():
    N, d, K = 2000, 6, 3
    W = rng.normal(0, 1, (K, d)); b = rng.normal(0, 1, K)
    Z = rng.normal(0, 1, (N, d))
    A = 0.2 + 0.8 * (1 / (1 + np.exp(-rng.normal(0, 1, (N, d)))))   # positive gates
    f = (A * Z) @ W.T + b
    Dv = np.exp(rng.normal(0, 1.0, d))                 # positive diagonal rescale
    Wp = W * Dv[None, :]; Ap = A / Dv[None, :]
    fp = (Ap * Z) @ Wp.T + b
    pred_diff = float(np.max(np.abs(f - fp)))
    meanlog = np.mean(np.log(A), 0); meanlog_p = np.mean(np.log(Ap), 0)
    # log-centering: divide each gate by exp(E[log a_j]); centered means -> 0
    c = np.exp(meanlog); A_c = A / c
    centered_mean = np.mean(np.log(A_c), 0)
    out = dict(max_prediction_diff=pred_diff,
               gate_meanlog_shift=float(np.max(np.abs((meanlog_p - meanlog) + np.log(Dv)))),
               centered_meanlog_absmax=float(np.max(np.abs(centered_mean))))
    pd.DataFrame([out]).to_csv(os.path.join(RES, "theory_T4_identifiability.csv"), index=False)
    print("T4: max|f-f'| =", f"{pred_diff:.2e}", "(identical predictions); "
          "centered E[log a] absmax =", f"{out['centered_meanlog_absmax']:.2e}")
    return out


# ---------------- T5: eps sensitivity on real data ------------------------
def t5_eps_sensitivity():
    import datasets as Dt
    import models as M
    from common import rmse, logratio_rmse
    d = Dt.LOADERS["airq"](); w = Dt.make_windows(d, L=24, horizon=12)
    sp = w["split"]; tr, te = sp["train"], sp["test"]
    yte, ate = w["ynext"][te], w["anchor"][te]
    ymed = float(np.median(w["ynext"]))
    epss = np.array([0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0]) * 0.1   # spans sub- to super-median
    rows = []
    for e in epss:
        yhat, _ = M.ridge_logratio(w, tr, te, e)
        rows.append(dict(eps=float(e), eps_over_median=float(e / ymed),
                         RMSE=rmse(yte, yhat), logRMSE=logratio_rmse(yte, yhat, ate, e)))
    df = pd.DataFrame(rows); df.to_csv(os.path.join(RES, "theory_T5_eps.csv"), index=False)
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    ax.plot(df.eps, df.RMSE, "o-", lw=2)
    ax.set_xscale("log"); ax.set_xlabel(r"shift $\varepsilon$ (benzene units)")
    ax.set_ylabel("test RMSE"); ax.set_title(r"Sensitivity to $\varepsilon$ (Ridge-Alpha, Air Quality)")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "T5_eps_sensitivity.pdf")); plt.close(fig)
    print("T5 eps-sensitivity RMSE range:", round(df.RMSE.min(), 4), "-", round(df.RMSE.max(), 4))
    return df


if __name__ == "__main__":
    print("=== Theory-validation experiments ===")
    t1_shift_bias()
    t2_recovery()
    t3_multistep()
    t4_identifiability()
    t5_eps_sensitivity()
    print("=== done; figures in work/figs, tables in work/results ===")
