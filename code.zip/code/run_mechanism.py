"""Mechanism analysis requested by Reviewer 5 (minor revision, point 2).

Explains *why* the shifted log-ratio parameterization improves relative error:

  (a) Implicit weighting. Squared loss on rho = log(y_{t+1}+eps) - log(y_t+eps)
      corresponds, to first order, to a RELATIVE error criterion: an error delta in
      rho maps to a relative state error e^delta - 1 that is independent of level.
      Squared loss on the raw target maps to relative error delta/(y+eps), which
      explodes as y -> 0. Hence raw training implicitly down-weights small values.
  (b) Empirical consequence: the alpha advantage should be concentrated in the
      low-magnitude deciles, and the raw model should defend the top decile
      (which dominates RMSE). This also explains the observed RMSE trade-off.
  (c) Learned gate distribution: alpha_t = exp(eta_t) concentrates near 1 with an
      adaptive spread -- the identity gate is the learned default.

Outputs: work/figs/R5_mechanism.pdf and work/results/mechanism_<ds>.csv
"""
import os, sys, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(__file__))
import datasets as D
import models as M
import common as C

warnings.filterwarnings("ignore")
FIG = os.path.join(os.path.dirname(__file__), "..", "figs")
RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(FIG, exist_ok=True); os.makedirs(RES, exist_ok=True)
plt.rcParams.update({"font.size": 9, "figure.dpi": 130})
EPS = {"beijing": 1.0, "airq": 0.1, "energy": 1.0}
LABEL = {"beijing": "Beijing PM$_{2.5}$", "airq": "Air quality C$_6$H$_6$",
         "energy": "Appliance energy"}


def decile_analysis(ds, seeds=3):
    """Per-decile relative/absolute error for matched raw vs alpha MLP."""
    eps = EPS[ds]
    d = D.LOADERS[ds]()
    w = D.make_windows(d, L=24, horizon=12)
    sp = w["split"]; tr, va, te = sp["train"], sp["val"], sp["test"]
    yte, ate = w["ynext"][te], w["anchor"][te]
    preds, per_seed_eta = {}, []
    for mode in ["raw", "alpha"]:
        ps = []
        for s in range(seeds):
            yhat, _, _ = M.mlp_model(w, tr, va, te, mode=mode, eps=eps, seed=s)
            ps.append(yhat)
            if mode == "alpha":
                # gate of THIS model, not of the ensemble mean (averaging in raw
                # space would contract the dispersion we are trying to report)
                per_seed_eta.append(np.log(np.maximum(yhat, -eps + 1e-9) + eps)
                                    - np.log(ate + eps))
        preds[mode] = np.mean(ps, 0)
    etas = np.concatenate(per_seed_eta)   # pooled over seeds

    q = np.quantile(yte, np.linspace(0, 1, 11))
    q[-1] += 1e-9
    rows = []
    for i in range(10):
        m = (yte >= q[i]) & (yte < q[i + 1])
        if m.sum() < 5:
            continue
        rows.append(dict(
            dataset=ds, decile=i + 1, n=int(m.sum()),
            y_median=float(np.median(yte[m])),
            sMAPE_raw=C.smape(yte[m], preds["raw"][m]),
            sMAPE_alpha=C.smape(yte[m], preds["alpha"][m]),
            MAE_raw=C.mae(yte[m], preds["raw"][m]),
            MAE_alpha=C.mae(yte[m], preds["alpha"][m]),
            SSE_raw=float(np.sum((yte[m] - preds["raw"][m]) ** 2)),
            SSE_alpha=float(np.sum((yte[m] - preds["alpha"][m]) ** 2)),
        ))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, f"mechanism_{ds}.csv"), index=False)
    return df, etas, yte


def main():
    dfs, gates = {}, {}
    for ds in ["beijing", "airq", "energy"]:
        df, eta, yte = decile_analysis(ds)
        dfs[ds] = df; gates[ds] = np.exp(eta)
        print(f"[{ds}] decile analysis done")

    fig, axes = plt.subplots(2, 2, figsize=(9.4, 6.6))

    # (a) implicit weighting: relative error induced by a fixed absolute error
    ax = axes[0, 0]
    y = np.logspace(-1, 3, 400)
    for delta, c in [(1.0, "tab:red"), (5.0, "tab:orange")]:
        ax.plot(y, delta / (y + 1.0), color=c, lw=1.8,
                label=fr"raw target, $|\Delta y|={delta:g}$")
    for dl, c in [(0.05, "tab:blue"), (0.20, "tab:cyan")]:
        ax.plot(y, np.full_like(y, np.exp(dl) - 1.0), color=c, lw=1.8, ls="--",
                label=fr"alpha target, $|\Delta\rho|={dl:g}$")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("state level $y$"); ax.set_ylabel("induced relative error")
    ax.set_title("(a) Implicit error criterion", fontsize=9.5)
    ax.legend(fontsize=6.6, loc="upper right"); ax.grid(alpha=0.25)

    # (b) where the alpha gain lives: sMAPE gain by decile
    ax = axes[0, 1]
    for ds, c in zip(["beijing", "airq", "energy"], ["tab:blue", "tab:green", "tab:purple"]):
        df = dfs[ds]
        gain = df.sMAPE_raw.values - df.sMAPE_alpha.values
        ax.plot(df.decile.values, gain, "o-", color=c, lw=1.6, ms=3.6, label=LABEL[ds])
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xlabel("decile of the target $y_{t+1}$ (1 = smallest)")
    ax.set_ylabel("sMAPE gain of alpha (pp)")
    ax.set_title("(b) Alpha gain concentrates at small states", fontsize=9.5)
    ax.legend(fontsize=6.8); ax.grid(alpha=0.25)

    # (c) squared-error share by decile: who owns RMSE
    ax = axes[1, 0]
    ds = "energy"; df = dfs[ds]
    share_r = 100 * df.SSE_raw.values / df.SSE_raw.values.sum()
    share_a = 100 * df.SSE_alpha.values / df.SSE_alpha.values.sum()
    wdt = 0.4
    ax.bar(df.decile.values - wdt / 2, share_r, wdt, label="raw", color="tab:red", alpha=0.85)
    ax.bar(df.decile.values + wdt / 2, share_a, wdt, label="alpha", color="tab:blue", alpha=0.85)
    ax.set_xlabel("decile of the target $y_{t+1}$")
    ax.set_ylabel("share of total squared error (%)")
    ax.set_title(f"(c) Squared error is dominated by the top decile\n({LABEL[ds]})", fontsize=9.5)
    ax.legend(fontsize=7); ax.grid(alpha=0.25, axis="y")

    # (d) learned gate distribution
    ax = axes[1, 1]
    for ds, c in zip(["beijing", "airq", "energy"], ["tab:blue", "tab:green", "tab:purple"]):
        g = gates[ds]
        g = g[(g > 0) & np.isfinite(g)]
        ax.hist(np.log(g), bins=80, histtype="step", density=True, color=c, lw=1.5,
                label=f"{LABEL[ds]}  (sd {np.std(np.log(g)):.2f})")
    ax.axvline(0.0, color="k", lw=1.0, ls=":")
    ax.set_xlim(-1.6, 1.6)
    ax.set_xlabel(r"learned log-gate $\eta_t=\log\alpha_t$")
    ax.set_ylabel("density")
    ax.set_title(r"(d) Learned gates centre on the identity $\alpha_t\!=\!1$", fontsize=9.5)
    ax.legend(fontsize=6.4); ax.grid(alpha=0.25)

    fig.tight_layout()
    out = os.path.join(FIG, "R5_mechanism.pdf")
    fig.savefig(out); plt.close(fig)
    print("wrote", out)

    # console summary with exactly the quantities quoted in the manuscript
    for ds in dfs:
        df = dfs[ds]
        g = (df.sMAPE_raw - df.sMAPE_alpha).values
        mae_ratio = df.MAE_alpha.values[0] / df.MAE_raw.values[0]
        share = 100 * df.SSE_raw.values[-1] / df.SSE_raw.values.sum()
        monotone = bool(np.all(np.diff(g) <= 1e-9))
        print(f"  {ds}: d1 gain={g[0]:.1f}pp (sMAPE {df.sMAPE_raw.values[0]:.1f}->"
              f"{df.sMAPE_alpha.values[0]:.1f}; MAE {df.MAE_raw.values[0]:.2f}->"
              f"{df.MAE_alpha.values[0]:.2f} = {100*(1-mae_ratio):.0f}% cut) | "
              f"top-decile gain={g[-1]:.1f}pp | max gain at decile {int(np.argmax(g))+1} | "
              f"monotone_decay={monotone} | top-decile SSE share={share:.0f}% | "
              f"gate sd={np.std(np.log(gates[ds][np.isfinite(gates[ds]) & (gates[ds]>0)])):.2f}")


if __name__ == "__main__":
    main()
