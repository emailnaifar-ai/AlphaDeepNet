"""Models: classical/ML baselines and AlphaDeepNet variants.

The decisive comparison is *same backbone, two target parameterizations*:
  RAW   : the network predicts the next value directly (additive).
  ALPHA : the network predicts the shifted log-ratio eta_t and forms
          yhat_{t+1} = (y_t + eps) * exp(eta_t) - eps   (multiplicative).
Everything else (features, architecture, optimizer, budget) is held fixed,
so any difference isolates the AlphaDeepNet parameterization itself.
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.linear_model import Ridge
from sklearn.ensemble import HistGradientBoostingRegressor
from common import set_seed

DEVICE = "cpu"


# ----------------------------- helpers ------------------------------------
def shifted_logratio(ynext, anchor, eps):
    return np.log(ynext + eps) - np.log(anchor + eps)


def invert_alpha(eta, anchor, eps):
    return (anchor + eps) * np.exp(eta) - eps


# --------------------------- simple baselines -----------------------------
def persistence(w, sp):
    return w["anchor"][sp]


def seasonal_naive(w, sp):
    s = w["season"]
    idx = w["idx"][sp]
    y = w["y_raw"]
    out = np.empty(len(idx), np.float32)
    for i, t in enumerate(idx):
        j = t + 1 - s
        out[i] = y[j] if j >= 0 else y[t]   # fall back to persistence early on
    return out


def ridge_raw(w, sp_tr, sp_te, alpha=1.0):
    m = Ridge(alpha=alpha)
    m.fit(w["Xtab"][sp_tr], w["ynext"][sp_tr])
    return m.predict(w["Xtab"][sp_te]).astype(np.float32)


def ridge_logratio(w, sp_tr, sp_te, eps, alpha=1.0):
    """Theorem-5 closed-form ridge estimator of the shifted log-ratio."""
    rho = shifted_logratio(w["ynext"][sp_tr], w["anchor"][sp_tr], eps)
    m = Ridge(alpha=alpha)
    m.fit(w["Xtab"][sp_tr], rho)
    eta = m.predict(w["Xtab"][sp_te])
    return invert_alpha(eta, w["anchor"][sp_te], eps).astype(np.float32), m


def gbm_raw(w, sp_tr, sp_te, seed=0):
    m = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05,
                                      max_depth=6, l2_regularization=1.0,
                                      random_state=seed)
    m.fit(w["Xtab"][sp_tr], w["ynext"][sp_tr])
    return m.predict(w["Xtab"][sp_te]).astype(np.float32)


def gbm_logratio(w, sp_tr, sp_te, eps, seed=0):
    rho = shifted_logratio(w["ynext"][sp_tr], w["anchor"][sp_tr], eps)
    m = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05,
                                      max_depth=6, l2_regularization=1.0,
                                      random_state=seed)
    m.fit(w["Xtab"][sp_tr], rho)
    eta = m.predict(w["Xtab"][sp_te])
    return invert_alpha(eta, w["anchor"][sp_te], eps).astype(np.float32)


# ------------------------------ networks ----------------------------------
class MLP(nn.Module):
    def __init__(self, d_in, hidden=128, depth=2, out=1):
        super().__init__()
        layers, d = [], d_in
        for _ in range(depth):
            layers += [nn.Linear(d, hidden), nn.ReLU()]
            d = hidden
        layers += [nn.Linear(d, out)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


class LSTMHead(nn.Module):
    def __init__(self, n_feat, n_cal, hidden=64, out=1):
        super().__init__()
        self.lstm = nn.LSTM(n_feat, hidden, batch_first=True)
        self.head = nn.Sequential(nn.Linear(hidden + n_cal, hidden), nn.ReLU(),
                                  nn.Linear(hidden, out))

    def forward(self, xseq, xcal):
        _, (h, _) = self.lstm(xseq)
        z = torch.cat([h[-1], xcal], dim=1)
        return self.head(z)


# ----------------------------- training -----------------------------------
def _train_torch(model, Xtr, Ytr, Xva, Yva, *, loss_fn, seq=False, calnext=None,
                 sp_tr=None, sp_va=None, max_epochs=120, patience=12, lr=1e-3,
                 wd=1e-5, batch=256, eta_reg=0.0, seed=0):
    set_seed(seed)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)
    n = len(Ytr)
    best, best_state, bad = np.inf, None, 0
    Ytr_t = torch.tensor(Ytr).float().view(-1, 1)
    Yva_t = torch.tensor(Yva).float().view(-1, 1)
    for ep in range(max_epochs):
        model.train()
        perm = np.random.permutation(n)
        for s in range(0, n, batch):
            bi = perm[s:s + batch]
            opt.zero_grad()
            if seq:
                out = model(Xtr[0][bi], Xtr[1][bi])
            else:
                out = model(Xtr[bi])
            loss = loss_fn(out, Ytr_t[bi])
            if eta_reg > 0:
                loss = loss + eta_reg * (out ** 2).mean()
            loss.backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            out = model(Xva[0], Xva[1]) if seq else model(Xva)
            vl = loss_fn(out, Yva_t).item()
        if vl < best - 1e-6:
            best, best_state, bad = vl, {k: v.clone() for k, v in model.state_dict().items()}, 0
        else:
            bad += 1
            if bad >= patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model


def mlp_model(w, sp_tr, sp_va, sp_te, *, mode, eps, seed=0, hidden=128, depth=2,
              eta_reg=0.0, hetero=False):
    """mode in {'raw','alpha'}. Returns (yhat_test, model, aux)."""
    Xtr = torch.tensor(w["Xtab"][sp_tr]).float()
    Xva = torch.tensor(w["Xtab"][sp_va]).float()
    Xte = torch.tensor(w["Xtab"][sp_te]).float()
    a_te = w["anchor"][sp_te]
    if mode == "raw":
        mu, sd = w["ynext"][sp_tr].mean(), w["ynext"][sp_tr].std() + 1e-6
        Ytr = (w["ynext"][sp_tr] - mu) / sd
        Yva = (w["ynext"][sp_va] - mu) / sd
        out_dim = 1
    else:  # alpha
        Ytr = shifted_logratio(w["ynext"][sp_tr], w["anchor"][sp_tr], eps)
        Yva = shifted_logratio(w["ynext"][sp_va], w["anchor"][sp_va], eps)
        out_dim = 2 if hetero else 1
    model = MLP(w["Xtab"].shape[1], hidden=hidden, depth=depth, out=out_dim)

    if hetero and mode == "alpha":
        def loss_fn(out, y):
            mu_, logv = out[:, :1], out[:, 1:2]
            return 0.5 * (((y - mu_) ** 2) / torch.exp(logv) + logv).mean()
    else:
        mse = nn.MSELoss()
        def loss_fn(out, y):
            return mse(out[:, :1] if out.shape[1] > 1 else out, y)

    model = _train_torch(model, Xtr, Ytr, Xva, Yva, loss_fn=loss_fn,
                         eta_reg=eta_reg, seed=seed)
    model.eval()
    with torch.no_grad():
        pred = model(Xte).numpy()
    aux = {}
    if mode == "raw":
        yhat = pred[:, 0] * sd + mu
    else:
        eta = pred[:, 0]
        yhat = invert_alpha(eta, a_te, eps)
        if hetero:
            sigma = np.sqrt(np.exp(pred[:, 1]))
            lo = invert_alpha(eta - 1.96 * sigma, a_te, eps)
            hi = invert_alpha(eta + 1.96 * sigma, a_te, eps)
            aux = dict(lo=lo, hi=hi, eta_mu=eta, eta_sigma=sigma,
                       anchor=a_te, eps=eps)
    return yhat.astype(np.float32), model, aux


def mlp_transform_model(w, sp_tr, sp_va, sp_te, *, transform, eps, seed=0,
                        hidden=128, depth=2):
    """Target-parameterization ablation on a fixed MLP backbone.

    transform in {'logstate','log1p','boxcox','delta'} -- isolates whether the
    AlphaDeepNet gain is from a log transform, a residual, or specifically the
    shifted log-RATIO (anchor subtraction). Returns raw-scale test predictions.
    Also returns val predictions (for split-conformal).
    """
    from scipy.special import inv_boxcox
    from scipy.stats import boxcox as boxcox_fit
    Xtr = torch.tensor(w["Xtab"][sp_tr]).float()
    Xva = torch.tensor(w["Xtab"][sp_va]).float()
    Xte = torch.tensor(w["Xtab"][sp_te]).float()
    y_tr, y_va, y_te = w["ynext"][sp_tr], w["ynext"][sp_va], w["ynext"][sp_te]
    a_va, a_te = w["anchor"][sp_va], w["anchor"][sp_te]

    lam = None
    if transform == "raw":
        fwd = lambda y, a: y.astype(float)
        inv = lambda t, a: t
    elif transform == "alpha":
        fwd = lambda y, a: np.log(y + eps) - np.log(a + eps)
        inv = lambda t, a: (a + eps) * np.exp(t) - eps
    elif transform == "logstate":
        fwd = lambda y, a: np.log(y + eps)
        inv = lambda t, a: np.exp(t) - eps
    elif transform == "log1p":
        fwd = lambda y, a: np.log1p(y)
        inv = lambda t, a: np.expm1(t)
    elif transform == "delta":
        fwd = lambda y, a: y - a
        inv = lambda t, a: a + t
    elif transform == "boxcox":
        _, lam = boxcox_fit(y_tr + eps)
        fwd = lambda y, a: (np.power(y + eps, lam) - 1.0) / lam if abs(lam) > 1e-8 else np.log(y + eps)
        _T = fwd(y_tr, None); _tlo, _thi = float(_T.min()), float(_T.max())

        def inv(t, a):
            t = np.clip(t, _tlo, _thi)               # do not extrapolate the monotone transform
            if abs(lam) <= 1e-8:
                return np.exp(t) - eps
            base = np.maximum(lam * t + 1.0, 1e-12)
            return np.power(base, 1.0 / lam) - eps
    else:
        raise ValueError(transform)

    Ttr = fwd(y_tr, w["anchor"][sp_tr]); mu, sd = Ttr.mean(), Ttr.std() + 1e-6
    Ttr_s = (Ttr - mu) / sd
    Tva_s = (fwd(y_va, a_va) - mu) / sd
    model = MLP(w["Xtab"].shape[1], hidden=hidden, depth=depth, out=1)
    mse = nn.MSELoss()
    model = _train_torch(model, Xtr, Ttr_s, Xva, Tva_s, loss_fn=lambda o, y: mse(o, y), seed=seed)
    model.eval()
    with torch.no_grad():
        Tte = model(Xte).numpy()[:, 0] * sd + mu
        Tval = model(Xva).numpy()[:, 0] * sd + mu
    yhat = inv(Tte, a_te)
    yval = inv(Tval, a_va)
    return np.asarray(yhat, np.float32), np.asarray(yval, np.float32)


def mlp_raw_hetero(w, sp_tr, sp_va, sp_te, *, seed=0, hidden=128, depth=2):
    """Heteroscedastic MLP predicting the raw target directly (calibration baseline).

    Returns (point yhat, mu_raw, sigma_raw) on the original scale.
    """
    Xtr = torch.tensor(w["Xtab"][sp_tr]).float()
    Xva = torch.tensor(w["Xtab"][sp_va]).float()
    Xte = torch.tensor(w["Xtab"][sp_te]).float()
    mu0, sd0 = w["ynext"][sp_tr].mean(), w["ynext"][sp_tr].std() + 1e-6
    Ytr = (w["ynext"][sp_tr] - mu0) / sd0
    Yva = (w["ynext"][sp_va] - mu0) / sd0
    model = MLP(w["Xtab"].shape[1], hidden=hidden, depth=depth, out=2)

    def loss_fn(out, y):
        m_, logv = out[:, :1], out[:, 1:2]
        logv = torch.clamp(logv, -8, 8)            # numerical stability
        return 0.5 * (((y - m_) ** 2) / torch.exp(logv) + logv).mean()

    model = _train_torch(model, Xtr, Ytr, Xva, Yva, loss_fn=loss_fn, seed=seed)
    model.eval()
    with torch.no_grad():
        pred = model(Xte).numpy()
    mu_raw = pred[:, 0] * sd0 + mu0
    sigma_raw = np.sqrt(np.exp(np.clip(pred[:, 1], -8, 8))) * sd0
    return mu_raw.astype(np.float32), mu_raw.astype(np.float32), sigma_raw.astype(np.float32)


def lstm_model(w, sp_tr, sp_va, sp_te, *, mode, eps, seed=0, hidden=64):
    Xs = torch.tensor(w["Xseq"]).float()
    Xc = torch.tensor(w["calnext"]).float()
    tr = (Xs[sp_tr], Xc[sp_tr]); va = (Xs[sp_va], Xc[sp_va]); te = (Xs[sp_te], Xc[sp_te])
    a_te = w["anchor"][sp_te]
    if mode == "raw":
        mu, sd = w["ynext"][sp_tr].mean(), w["ynext"][sp_tr].std() + 1e-6
        Ytr = (w["ynext"][sp_tr] - mu) / sd
        Yva = (w["ynext"][sp_va] - mu) / sd
    else:
        Ytr = shifted_logratio(w["ynext"][sp_tr], w["anchor"][sp_tr], eps)
        Yva = shifted_logratio(w["ynext"][sp_va], w["anchor"][sp_va], eps)
    model = LSTMHead(w["n_cov"], w["calnext"].shape[1], hidden=hidden, out=1)
    mse = nn.MSELoss()
    model = _train_torch(model, tr, Ytr, va, Yva, loss_fn=lambda o, y: mse(o, y),
                         seq=True, seed=seed)
    model.eval()
    with torch.no_grad():
        pred = model(te[0], te[1]).numpy()[:, 0]
    yhat = pred * sd + mu if mode == "raw" else invert_alpha(pred, a_te, eps)
    return yhat.astype(np.float32), model
