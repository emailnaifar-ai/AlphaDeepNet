"""Loading and windowing of three public positive-state time-series datasets.

All three are nonnegative target series with exogenous covariates that plausibly
influence the next state -- the natural setting for the alpha-ratio model:
  * beijing  : hourly PM2.5 concentration (ug/m^3) + meteorology (UCI 381).
  * airq     : hourly benzene C6H6 (ug/m^3) + temperature/humidity (UCI 360).
  * energy   : 10-min household appliance energy use (Wh) + outdoor weather.

Windowing convention (no leakage):
  Information set at time t to predict y_{t+1}:
    - target lags  y[t-L+1 .. t]
    - covariates   c[t-L+1 .. t]      (observed, no future peeking)
    - calendar features of the *target* step t+1 (deterministic, known ahead).
  anchor a_t = y[t]   (used by the multiplicative/log-ratio models).
Splits are strictly temporal: first 70% train, next 15% val, last 15% test.
"""
import os
import numpy as np
import pandas as pd

DATA = os.path.join(os.path.dirname(__file__), "..", "data")


def _cyc(values, period):
    ang = 2.0 * np.pi * (values % period) / period
    return np.sin(ang), np.cos(ang)


def _interp_short(s: pd.Series, limit: int):
    """Linearly interpolate gaps up to `limit`, then drop remaining NaNs."""
    return s.interpolate(method="linear", limit=limit, limit_area="inside")


def load_beijing():
    df = pd.read_csv(os.path.join(DATA, "beijing", "PRSA_data_2010.1.1-2014.12.31.csv"))
    df["ts"] = pd.to_datetime(df[["year", "month", "day", "hour"]])
    df = df.sort_values("ts").reset_index(drop=True)
    df["y"] = _interp_short(df["pm2.5"], limit=6)
    cov = df[["DEWP", "TEMP", "PRES", "Iws", "Is", "Ir"]].copy()
    cov = cov.interpolate(limit=6).ffill().bfill()
    hr_s, hr_c = _cyc(df["hour"].values, 24)
    mo_s, mo_c = _cyc(df["month"].values, 12)
    cal = pd.DataFrame({"hr_s": hr_s, "hr_c": hr_c, "mo_s": mo_s, "mo_c": mo_c})
    keep = df["y"].notna().values
    return _assemble(df["ts"].values, df["y"].values, cov.values, cal.values,
                     cov.columns.tolist(), cal.columns.tolist(), keep,
                     name="beijing", target="PM2.5 (ug/m^3)", period=24)


def load_airq():
    df = pd.read_csv(os.path.join(DATA, "airquality", "AirQualityUCI.csv"),
                     sep=";", decimal=",")
    df = df.dropna(axis=1, how="all").dropna(axis=0, how="all")
    df["ts"] = pd.to_datetime(df["Date"] + " " + df["Time"].str.replace(".", ":", regex=False),
                              format="%d/%m/%Y %H:%M:%S")
    df = df.sort_values("ts").reset_index(drop=True)
    for c in ["C6H6(GT)", "T", "RH", "AH"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
        df.loc[df[c] <= -200, c] = np.nan       # -200 is the missing sentinel
    df["y"] = _interp_short(df["C6H6(GT)"], limit=6)
    cov = df[["T", "RH", "AH"]].interpolate(limit=6).ffill().bfill()
    hr_s, hr_c = _cyc(df["ts"].dt.hour.values, 24)
    dw_s, dw_c = _cyc(df["ts"].dt.dayofweek.values, 7)
    cal = pd.DataFrame({"hr_s": hr_s, "hr_c": hr_c, "dw_s": dw_s, "dw_c": dw_c})
    keep = df["y"].notna().values & (df["y"].values >= 0)
    return _assemble(df["ts"].values, df["y"].values, cov.values, cal.values,
                     cov.columns.tolist(), cal.columns.tolist(), keep,
                     name="airq", target="Benzene C6H6 (ug/m^3)", period=24)


def load_energy():
    df = pd.read_csv(os.path.join(DATA, "energy_appliances.csv"))
    df["ts"] = pd.to_datetime(df["date"])
    df = df.sort_values("ts").reset_index(drop=True)
    df["y"] = df["Appliances"].astype(float)
    cov = df[["lights", "T_out", "RH_out", "Press_mm_hg", "Windspeed",
              "Visibility", "Tdewpoint"]].astype(float)
    cov = cov.interpolate(limit=6).ffill().bfill()
    hr_s, hr_c = _cyc(df["ts"].dt.hour.values, 24)
    dw_s, dw_c = _cyc(df["ts"].dt.dayofweek.values, 7)
    cal = pd.DataFrame({"hr_s": hr_s, "hr_c": hr_c, "dw_s": dw_s, "dw_c": dw_c})
    keep = df["y"].notna().values
    return _assemble(df["ts"].values, df["y"].values, cov.values, cal.values,
                     cov.columns.tolist(), cal.columns.tolist(), keep,
                     name="energy", target="Appliance energy (Wh)", period=144)


def _assemble(ts, y, cov, cal, cov_names, cal_names, keep, name, target, period):
    return dict(ts=ts, y=y.astype(float), cov=cov.astype(float), cal=cal.astype(float),
                cov_names=cov_names, cal_names=cal_names, keep=keep,
                name=name, target=target, season=period)


LOADERS = {"beijing": load_beijing, "airq": load_airq, "energy": load_energy}


def make_windows(d, L=24, horizon=12):
    """Build windowed arrays + temporal split. Returns a dict of tensors."""
    y, cov, cal, keep = d["y"], d["cov"], d["cal"], d["keep"]
    n = len(y)
    Xseq, Xtab, calnext, anchor, ynext, idx = [], [], [], [], [], []
    # multi-step targets (contiguous future, covariates teacher-forced)
    fut_y = []
    for t in range(L - 1, n - horizon):
        sl = slice(t - L + 1, t + 1)
        if not keep[sl].all() or not keep[t + 1:t + 1 + horizon].all():
            continue
        ywin = y[sl]
        cwin = cov[sl]
        Xseq.append(np.concatenate([ywin[:, None], cwin], axis=1))
        Xtab.append(np.concatenate([ywin, cwin.reshape(-1), cal[t + 1]]))
        calnext.append(cal[t + 1])
        anchor.append(y[t])
        ynext.append(y[t + 1])
        fut_y.append(y[t + 1:t + 1 + horizon])
        idx.append(t)
    Xseq = np.asarray(Xseq, np.float32)
    Xtab = np.asarray(Xtab, np.float32)
    calnext = np.asarray(calnext, np.float32)
    anchor = np.asarray(anchor, np.float32)
    ynext = np.asarray(ynext, np.float32)
    fut_y = np.asarray(fut_y, np.float32)
    idx = np.asarray(idx)

    N = len(idx)
    i_tr, i_va = int(0.70 * N), int(0.85 * N)
    sp = dict(train=slice(0, i_tr), val=slice(i_tr, i_va), test=slice(i_va, N))

    # standardize covariate channels of the sequence and tabular features by TRAIN stats
    seq_mu = Xseq[sp["train"]].reshape(-1, Xseq.shape[2]).mean(0)
    seq_sd = Xseq[sp["train"]].reshape(-1, Xseq.shape[2]).std(0) + 1e-6
    # do NOT standardize the raw target channel inside the seq for the alpha model;
    # we keep a standardized copy for NN inputs but predictions use raw anchor.
    Xseq_n = (Xseq - seq_mu) / seq_sd
    tab_mu = Xtab[sp["train"]].mean(0)
    tab_sd = Xtab[sp["train"]].std(0) + 1e-6
    Xtab_n = (Xtab - tab_mu) / tab_sd

    return dict(Xseq=Xseq_n, Xtab=Xtab_n, Xseq_raw=Xseq, Xtab_raw=Xtab,
                calnext=calnext, anchor=anchor,
                ynext=ynext, fut_y=fut_y, idx=idx, split=sp,
                seq_mu=seq_mu, seq_sd=seq_sd, tab_mu=tab_mu, tab_sd=tab_sd,
                n_cov=Xseq.shape[2], L=L, horizon=horizon,
                name=d["name"], target=d["target"], season=d["season"],
                y_raw=d["y"])


if __name__ == "__main__":
    for nm, fn in LOADERS.items():
        d = fn()
        y = d["y"][d["keep"]]
        w = make_windows(d, L=24, horizon=12)
        print(f"{nm:8s} target={d['target']:24s} kept={int(d['keep'].sum()):6d} "
              f"windows={len(w['idx']):6d}  y[min={y.min():.2f} max={y.max():.1f} "
              f"mean={y.mean():.2f} zeros={int((y==0).sum())}]  "
              f"covars={d['cov_names']}")
