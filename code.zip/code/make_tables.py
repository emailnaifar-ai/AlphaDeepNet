"""Generate LaTeX tables from the experiment CSVs (booktabs) for the Q1 manuscript.
Writes .tex fragments to work/q1/tables/ to be \\input by AlphaDeepNet.tex.
"""
import os, sys
import numpy as np
import pandas as pd

RES = os.path.join(os.path.dirname(__file__), "..", "results")
TAB = os.environ.get("ADN_TABDIR",
                     os.path.join(os.path.dirname(__file__), "..", "q1", "tables"))
os.makedirs(TAB, exist_ok=True)

DATASETS = [("beijing", "Beijing PM2.5"), ("airq", "Air Quality (C$_6$H$_6$)"),
            ("energy", "Appliance Energy")]
ORDER = ["Persistence", "SeasonalNaive", "Ridge-Raw", "Ridge-Alpha(Thm5)",
         "GBM-Raw", "GBM-Alpha", "MLP-Raw", "MLP-Alpha", "MLP-Alpha-Hetero",
         "LSTM-Raw", "LSTM-Alpha"]
PRETTY = {"Persistence": "Persistence", "SeasonalNaive": "Seasonal naive",
          "Ridge-Raw": "Ridge (raw)", "Ridge-Alpha(Thm5)": r"Ridge-$\alpha$",
          "GBM-Raw": "GBM (raw)", "GBM-Alpha": r"GBM-$\alpha$",
          "MLP-Raw": "MLP (raw)", "MLP-Alpha": r"MLP-$\alpha$",
          "MLP-Alpha-Hetero": r"MLP-$\alpha$ (het.)",
          "LSTM-Raw": "LSTM (raw)", "LSTM-Alpha": r"LSTM-$\alpha$"}


def _load(prefix, ds, index=None):
    p = os.path.join(RES, f"{prefix}_{ds}.csv")
    if not os.path.exists(p):
        return None
    df = pd.read_csv(p)
    return df.set_index(index) if index else df


def fmt(v, nd=2):
    return "--" if (v is None or (isinstance(v, float) and np.isnan(v))) else f"{v:.{nd}f}"


def cell(df, mdl, metric, nd, best):
    if mdl not in df.index:
        return "--"
    v = df.loc[mdl, metric]
    s = df.loc[mdl, metric + "_std"] if (metric + "_std") in df.columns else np.nan
    txt = fmt(v, nd)
    if not (isinstance(s, float) and np.isnan(s)) and s > 0:
        txt = f"{v:.{nd}f}$\\pm${s:.{nd}f}"
    if abs(v - best) < 1e-9:
        txt = r"\textbf{" + txt + "}"
    return txt


def main_table():
    frames = {ds: _load("forecast", ds, "model") for ds, _ in DATASETS}
    avail = [(ds, lab) for ds, lab in DATASETS if frames[ds] is not None]
    metrics = [("RMSE", 2), ("MAE", 2), ("sMAPE", 1)]
    best = {ds: {m: frames[ds][m].min() for m, _ in metrics} for ds, _ in avail}
    L = [r"\begin{tabular}{l" + "ccc" * len(avail) + "}", r"\toprule",
         "Model" + "".join([r" & \multicolumn{3}{c}{%s}" % lab for _, lab in avail]) + r" \\",
         "".join([r"\cmidrule(lr){%d-%d}" % (2 + 3 * i, 4 + 3 * i) for i in range(len(avail))]),
         "" + " & RMSE & MAE & sMAPE" * len(avail) + r" \\", r"\midrule"]
    for mdl in ORDER:
        if all(mdl not in frames[ds].index for ds, _ in avail):
            continue
        row = PRETTY.get(mdl, mdl)
        for ds, _ in avail:
            for m, nd in metrics:
                row += " & " + cell(frames[ds], mdl, m, nd, best[ds][m])
        L.append(row + r" \\")
        if mdl == "SeasonalNaive":
            L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabular}"]
    open(os.path.join(TAB, "main_results.tex"), "w").write("\n".join(L))
    print("main_results.tex:", len(avail), "datasets")


def transform_table():
    order = ["raw", "logstate", "log1p", "boxcox", "delta", "alpha"]
    pretty = {"raw": "raw $y$", "logstate": r"$\log(y{+}\eps)$", "log1p": r"$\log(1{+}y)$",
              "boxcox": "Box--Cox", "delta": r"delta $y_{t+1}{-}y_t$",
              "alpha": r"\textbf{alpha (log-ratio)}"}
    frames = {ds: _load("transform", ds, "transform") for ds, _ in DATASETS}
    avail = [(ds, lab) for ds, lab in DATASETS if frames[ds] is not None]
    metrics = [("RMSE", 2), ("MAE", 2), ("sMAPE", 1)]
    best = {ds: {m: frames[ds][m].min() for m, _ in metrics} for ds, _ in avail}
    L = [r"\begin{tabular}{l" + "ccc" * len(avail) + "}", r"\toprule",
         "Target" + "".join([r" & \multicolumn{3}{c}{%s}" % lab for _, lab in avail]) + r" \\",
         "".join([r"\cmidrule(lr){%d-%d}" % (2 + 3 * i, 4 + 3 * i) for i in range(len(avail))]),
         "" + " & RMSE & MAE & sMAPE" * len(avail) + r" \\", r"\midrule"]
    for tf in order:
        row = pretty[tf]
        for ds, _ in avail:
            for m, nd in metrics:
                row += " & " + cell(frames[ds], tf, m, nd, best[ds][m])
        L.append(row + r" \\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open(os.path.join(TAB, "transform.tex"), "w").write("\n".join(L))
    print("transform.tex written")


def dmmulti_table():
    pretty = {"sq": "squared", "abs": "absolute", "smape": "sMAPE"}
    L = [r"\begin{tabular}{llrrl}", r"\toprule",
         r"Dataset & Backbone, loss & DM & $p$ & Favors \\", r"\midrule"]
    for ds, lab in DATASETS:
        df = _load("dmmulti", ds)
        if df is None:
            continue
        for _, r in df.iterrows():
            p = r["p_value"]
            star = "" if p >= 0.05 else (r"$^{***}$" if p < 0.001 else (r"$^{**}$" if p < 0.01 else r"$^{*}$"))
            ps = "$<$0.001" if p < 0.001 else f"{p:.3f}"
            L.append(f"{lab} & {r['backbone']}, {pretty[r['loss']]} & {r['DM']:.2f} & {ps} & {r['favors']}{star} \\\\")
        L.append(r"\midrule")
    L[-1] = r"\bottomrule"
    L.append(r"\end{tabular}")
    open(os.path.join(TAB, "dmmulti.tex"), "w").write("\n".join(L))
    print("dmmulti.tex written")


def calib_table():
    pretty = {"alpha-hetero": r"MLP-$\alpha$ heterosc.", "raw-hetero": "MLP raw heterosc.",
              "alpha-conformal": r"MLP-$\alpha$ conformal"}
    L = [r"\begin{tabular}{llccccc}", r"\toprule",
         r"Dataset & Model & PICP & MPIW & Winkler & CRPS & NLL \\", r"\midrule"]
    for ds, lab in DATASETS:
        df = _load("calib", ds)
        if df is None:
            continue
        for _, r in df.iterrows():
            L.append(f"{lab} & {pretty.get(r['model'], r['model'])} & {fmt(r['PICP'],3)} & "
                     f"{fmt(r['MPIW'],2)} & {fmt(r['Winkler'],2)} & {fmt(r['CRPS'],3)} & {fmt(r['NLL'],3)} \\\\")
        L.append(r"\midrule")
    L[-1] = r"\bottomrule"
    L.append(r"\end{tabular}")
    open(os.path.join(TAB, "calibration.tex"), "w").write("\n".join(L))
    print("calibration.tex written")


def theory_table():
    def g(fn, col):
        p = os.path.join(RES, fn)
        return pd.read_csv(p).iloc[0][col] if os.path.exists(p) else np.nan
    t1 = (pd.read_csv(os.path.join(RES, "theory_T1_shift_bias.csv"))["max_violation"].max()
          if os.path.exists(os.path.join(RES, "theory_T1_shift_bias.csv")) else np.nan)
    t3 = (pd.read_csv(os.path.join(RES, "theory_T3_multistep.csv"))["max_violation"].max()
          if os.path.exists(os.path.join(RES, "theory_T3_multistep.csv")) else np.nan)
    r2 = g("theory_T2_recovery_b0eq0.csv", "R2")
    t4d = g("theory_T4_identifiability.csv", "max_prediction_diff")
    t4c = g("theory_T4_identifiability.csv", "centered_meanlog_absmax")
    L = [r"\begin{tabular}{lll}", r"\toprule",
         r"Result & Quantity checked & Empirical value \\", r"\midrule",
         r"Thm.~\ref{thm:shift} & $\max(|B_\eps|-\text{bound})$ on grid & $%.1e$ ($\leq 0$) \\" % t1,
         r"Thm.~\ref{thm:recovery} ($b_0{=}0$) & log-linear fit $R^2$ & $%.6f$ \\" % r2,
         r"Thm.~\ref{thm:multistep} & $\max(\text{empirical}-e^{k\delta}{+}1)$ & $%.1e$ ($\leq 0$) \\" % t3,
         r"Thm.~\ref{thm:ident} & $\max|f-f'|$ under gate rescaling & $%.1e$ \\" % t4d,
         r"Thm.~\ref{thm:ident} (centering) & $\max_j|\mathbb{E}\log a_j|$ after centering & $%.1e$ \\" % t4c,
         r"\bottomrule", r"\end{tabular}"]
    open(os.path.join(TAB, "theory_verification.tex"), "w").write("\n".join(L))
    print("theory_verification.tex written")


def dataset_table():
    import datasets as Dt
    eps = {"beijing": 1.0, "airq": 0.1, "energy": 1.0}
    tgt = {"beijing": r"PM$_{2.5}$ ($\mu$g/m$^3$)", "airq": r"benzene C$_6$H$_6$ ($\mu$g/m$^3$)",
           "energy": r"energy use (Wh)"}
    L = [r"\begin{tabular}{llrrrc}", r"\toprule",
         r"Dataset & Target (unit) & \#windows & train/val/test & $\eps$ & zeros \\", r"\midrule"]
    for ds, lab in DATASETS:
        d = Dt.LOADERS[ds](); w = Dt.make_windows(d, L=24, horizon=12)
        N = len(w["idx"]); ntr = int(.7 * N); nva = int(.85 * N) - ntr; nte = N - int(.85 * N)
        z = int((w["ynext"] == 0).sum())
        L.append(f"{lab} & {tgt[ds]} & {N} & {ntr}/{nva}/{nte} & {eps[ds]:g} & {z} \\\\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open(os.path.join(TAB, "datasets.tex"), "w").write("\n".join(L))
    print("datasets.tex written")


def sota_table():
    """Extended/SOTA baselines: raw vs alpha per backbone, best in bold, + GLMs."""
    pretty = {"lightgbm": "LightGBM", "xgboost": "XGBoost", "tcn": "TCN",
              "transformer": "Transformer", "nbeats": "N-BEATS"}
    glm = {"glm-tweedie": "Tweedie GLM", "glm-gamma": "Gamma GLM", "glm-poisson": "Poisson GLM",
           "glm-lognormal": "log-normal", "glm-quantile": "quantile reg."}
    frames = {ds: _load("sota", ds) for ds, _ in DATASETS}
    avail = [(ds, lab) for ds, lab in DATASETS if frames[ds] is not None]
    if not avail:
        print("sota_table skipped (no data)"); return
    for ds, _ in avail:
        frames[ds] = frames[ds].set_index("model")
    metrics = [("RMSE", 2), ("sMAPE", 1)]
    best = {ds: {m: frames[ds][m].min() for m, _ in metrics} for ds, _ in avail}
    L = [r"\begin{tabular}{l" + "cc" * len(avail) + "}", r"\toprule",
         "Model" + "".join([r" & \multicolumn{2}{c}{%s}" % lab for _, lab in avail]) + r" \\",
         "".join([r"\cmidrule(lr){%d-%d}" % (2 + 2 * i, 3 + 2 * i) for i in range(len(avail))]),
         "" + " & RMSE & sMAPE" * len(avail) + r" \\", r"\midrule"]
    order = []
    for b in ["lightgbm", "xgboost", "tcn", "transformer", "nbeats"]:
        order += [f"{b}-raw", f"{b}-alpha"]
    for key in order:
        lab = pretty[key.rsplit("-", 1)[0]] + (r"-$\alpha$" if key.endswith("alpha") else " (raw)")
        row = lab
        for ds, _ in avail:
            df = frames[ds]
            for m, nd in metrics:
                v = df.loc[key, m] if key in df.index else np.nan
                c = fmt(v, nd)
                if not np.isnan(v) and abs(v - best[ds][m]) < 1e-9:
                    c = r"\textbf{" + c + "}"
                row += " & " + c
        L.append(row + r" \\")
        if key.endswith("alpha"):
            L.append(r"\addlinespace[1pt]")
    L.append(r"\midrule")
    for key, lab in glm.items():
        row = lab
        for ds, _ in avail:
            df = frames[ds]
            for m, nd in metrics:
                v = df.loc[key, m] if key in df.index else np.nan
                row += " & " + fmt(v, nd)
        L.append(row + r" \\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open(os.path.join(TAB, "sota.tex"), "w").write("\n".join(L))
    print("sota.tex written")


def multistep_table():
    frames = {ds: _load("multistep", ds) for ds, _ in DATASETS}
    avail = [(ds, lab) for ds, lab in DATASETS if frames[ds] is not None]
    if not avail:
        print("multistep_table skipped"); return
    ks = [1, 3, 6, 12]
    L = [r"\begin{tabular}{ll" + "c" * len(ks) + "}", r"\toprule",
         r"Dataset & Model & \multicolumn{%d}{c}{sMAPE at horizon $k$} \\" % len(ks),
         r"\cmidrule(lr){3-%d}" % (2 + len(ks)),
         " & & " + " & ".join([f"$k{{=}}{k}$" for k in ks]) + r" \\", r"\midrule"]
    for ds, lab in avail:
        df = frames[ds]
        for mode, mlab in [("MLP-raw", "MLP (raw)"), ("MLP-alpha", r"MLP-$\alpha$")]:
            row = (lab if mode == "MLP-raw" else "") + " & " + mlab
            for k in ks:
                sub = df[(df.model == mode) & (df.k == k)]
                v = sub["sMAPE"].iloc[0] if len(sub) else np.nan
                best = df[df.k == k]["sMAPE"].min()
                c = fmt(v, 1)
                if not np.isnan(v) and abs(v - best) < 1e-9:
                    c = r"\textbf{" + c + "}"
                row += " & " + c
            L.append(row + r" \\")
        L.append(r"\addlinespace[1pt]")
    L[-1] = r"\bottomrule"
    L.append(r"\end{tabular}")
    open(os.path.join(TAB, "multistep.tex"), "w").write("\n".join(L))
    print("multistep.tex written")


def window_table():
    frames = {ds: _load("window", ds) for ds, _ in DATASETS}
    avail = [(ds, lab) for ds, lab in DATASETS if frames[ds] is not None]
    if not avail:
        print("window_table skipped"); return
    Ls = [12, 24, 48]
    L = [r"\begin{tabular}{ll" + "c" * len(Ls) + "}", r"\toprule",
         r"Dataset & Model & \multicolumn{%d}{c}{sMAPE at window $L$} \\" % len(Ls),
         r"\cmidrule(lr){3-%d}" % (2 + len(Ls)),
         " & & " + " & ".join([f"$L{{=}}{x}$" for x in Ls]) + r" \\", r"\midrule"]
    for ds, lab in avail:
        df = frames[ds]
        for mode, mlab in [("MLP-raw", "MLP (raw)"), ("MLP-alpha", r"MLP-$\alpha$")]:
            row = (lab if mode == "MLP-raw" else "") + " & " + mlab
            for x in Ls:
                sub = df[(df.model == mode) & (df.L == x)]
                v = sub["sMAPE"].iloc[0] if len(sub) else np.nan
                best = df[df.L == x]["sMAPE"].min()
                c = fmt(v, 1)
                if not np.isnan(v) and abs(v - best) < 1e-9:
                    c = r"\textbf{" + c + "}"
                row += " & " + c
            L.append(row + r" \\")
        L.append(r"\addlinespace[1pt]")
    L[-1] = r"\bottomrule"
    L.append(r"\end{tabular}")
    open(os.path.join(TAB, "window.tex"), "w").write("\n".join(L))
    print("window.tex written")


def eps_table():
    L = [r"\begin{tabular}{lccc}", r"\toprule",
         r"Dataset & val-selected $\eps$ & $\eps/\text{median}$ & test RMSE / sMAPE \\", r"\midrule"]
    ok = False
    for ds, lab in DATASETS:
        df = _load("eps", ds)
        if df is None:
            continue
        ok = True
        r = df[df.val_selected].iloc[0] if "val_selected" in df.columns else df.iloc[-1]
        L.append(f"{lab} & {r['eps']:g} & {r['eps_over_median']:.3f} & "
                 f"{r['test_RMSE']:.2f} / {r['test_sMAPE']:.1f} \\\\")
    if not ok:
        print("eps_table skipped"); return
    L += [r"\bottomrule", r"\end{tabular}"]
    open(os.path.join(TAB, "eps_selection.tex"), "w").write("\n".join(L))
    print("eps_selection.tex written")


def dmmulti_fdr_table():
    """DM table with Benjamini-Hochberg adjusted p-values across all comparisons."""
    from statsmodels.stats.multitest import multipletests
    pretty = {"sq": "squared", "abs": "absolute", "smape": "sMAPE"}
    allp, rows = [], []
    for ds, lab in DATASETS:
        df = _load("dmmulti", ds)
        if df is None:
            continue
        for _, r in df.iterrows():
            rows.append((lab, r["backbone"], r["loss"], r["DM"], r["p_value"], r["favors"]))
            allp.append(r["p_value"])
    if not rows:
        print("dmmulti_fdr skipped"); return
    adj = multipletests(allp, method="fdr_bh")[1]
    L = [r"\begin{tabular}{llrrrl}", r"\toprule",
         r"Dataset & Backbone, loss & DM & $p$ & $p_{\mathrm{BH}}$ & Favors \\", r"\midrule"]
    last = None
    for (lab, bk, loss, dm, p, fav), pa in zip(rows, adj):
        if last is not None and lab != last:
            L.append(r"\midrule")
        last = lab
        star = "" if pa >= 0.05 else (r"$^{***}$" if pa < 0.001 else (r"$^{**}$" if pa < 0.01 else r"$^{*}$"))
        ps = "$<$0.001" if p < 0.001 else f"{p:.3f}"
        pas = "$<$0.001" if pa < 0.001 else f"{pa:.3f}"
        L.append(f"{lab} & {bk}, {pretty[loss]} & {dm:.2f} & {ps} & {pas} & {fav}{star} \\\\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open(os.path.join(TAB, "dmmulti.tex"), "w").write("\n".join(L))
    print("dmmulti.tex (with BH-FDR) written")


def effectsize_table():
    """Percentage improvement of alpha over the matched raw backbone (R3.1)."""
    pairs = [("Ridge-Alpha(Thm5)", "Ridge-Raw", "Ridge"), ("GBM-Alpha", "GBM-Raw", "GBM"),
             ("MLP-Alpha", "MLP-Raw", "MLP"), ("LSTM-Alpha", "LSTM-Raw", "LSTM")]
    frames = {ds: _load("forecast", ds) for ds, _ in DATASETS}
    if all(v is None for v in frames.values()):
        print("effectsize skipped"); return
    for ds in frames:
        if frames[ds] is not None:
            frames[ds] = frames[ds].set_index("model")
    L = [r"\begin{tabular}{l" + "cc" * len(DATASETS) + "}", r"\toprule",
         "Backbone" + "".join([r" & \multicolumn{2}{c}{%s}" % lab for _, lab in DATASETS]) + r" \\",
         "".join([r"\cmidrule(lr){%d-%d}" % (2 + 2 * i, 3 + 2 * i) for i in range(len(DATASETS))]),
         "" + r" & $\Delta$MAE & $\Delta$sMAPE" * len(DATASETS) + r" \\", r"\midrule"]
    for a, r, lab in pairs:
        row = lab
        for ds, _ in DATASETS:
            df = frames[ds]
            if df is None or a not in df.index or r not in df.index:
                row += " & -- & --"; continue
            for m in ["MAE", "sMAPE"]:
                imp = 100.0 * (df.loc[r, m] - df.loc[a, m]) / df.loc[r, m]
                row += f" & {imp:+.1f}\\%"
        L.append(row + r" \\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open(os.path.join(TAB, "effectsize.tex"), "w").write("\n".join(L))
    print("effectsize.tex written")


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(__file__))
    main_table(); transform_table(); dmmulti_fdr_table(); calib_table(); theory_table()
    sota_table(); multistep_table(); window_table(); eps_table(); effectsize_table()
    try:
        dataset_table()
    except Exception as e:
        print("dataset_table skipped:", e)
