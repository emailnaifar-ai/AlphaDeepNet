"""Stronger / SOTA baselines requested by reviewers, each in raw and alpha (log-ratio)
target parameterizations where applicable.

Neural (sequence): TCN, Transformer encoder, N-BEATS (generic).
Trees:             LightGBM, XGBoost.
Statistical GLMs:  Tweedie, Gamma, Poisson, lognormal (log-target OLS), quantile (median).

The alpha version of any backbone predicts eta_t (shifted log-ratio) and forms
yhat = (y_t+eps)exp(eta)-eps; the raw version predicts the standardised next value.
"""
import numpy as np
import torch
import torch.nn as nn
from common import set_seed
from models import _train_torch, shifted_logratio, invert_alpha

DEVICE = "cpu"


# ----------------------------- neural backbones ---------------------------
class TCN(nn.Module):
    """Dilated causal temporal convolutional network + calendar head."""
    def __init__(self, n_feat, n_cal, ch=48, levels=3, k=3, out=1):
        super().__init__()
        layers, cin = [], n_feat
        for i in range(levels):
            d = 2 ** i
            layers += [nn.Conv1d(cin, ch, k, padding=(k - 1) * d, dilation=d), nn.ReLU()]
            cin = ch
        self.tcn = nn.Sequential(*layers)
        self.head = nn.Sequential(nn.Linear(ch + n_cal, ch), nn.ReLU(), nn.Linear(ch, out))
        self.k, self.levels = k, levels

    def forward(self, xseq, xcal):
        # xseq: (B, L, F) -> (B, F, L)
        z = xseq.transpose(1, 2)
        z = self.tcn(z)
        z = z[:, :, :xseq.shape[1]]          # trim causal padding
        z = z[:, :, -1]                       # last time step
        return self.head(torch.cat([z, xcal], dim=1))


class TransformerFore(nn.Module):
    def __init__(self, n_feat, n_cal, d_model=64, nhead=4, layers=2, out=1):
        super().__init__()
        self.inp = nn.Linear(n_feat, d_model)
        enc = nn.TransformerEncoderLayer(d_model, nhead, dim_feedforward=2 * d_model,
                                         batch_first=True, dropout=0.1)
        self.enc = nn.TransformerEncoder(enc, layers)
        self.head = nn.Sequential(nn.Linear(d_model + n_cal, d_model), nn.ReLU(),
                                  nn.Linear(d_model, out))

    def forward(self, xseq, xcal):
        h = self.enc(self.inp(xseq))
        h = h[:, -1, :]                       # last position
        return self.head(torch.cat([h, xcal], dim=1))


class NBeatsBlock(nn.Module):
    def __init__(self, d_in, width, theta):
        super().__init__()
        self.fc = nn.Sequential(nn.Linear(d_in, width), nn.ReLU(),
                                nn.Linear(width, width), nn.ReLU())
        self.back = nn.Linear(width, d_in)
        self.fore = nn.Linear(width, theta)

    def forward(self, x):
        h = self.fc(x)
        return self.back(h), self.fore(h)


class NBeats(nn.Module):
    """Generic N-BEATS on the flattened lag/covariate window + calendar."""
    def __init__(self, d_in, n_cal, width=128, blocks=3, out=1):
        super().__init__()
        self.blocks = nn.ModuleList([NBeatsBlock(d_in, width, out) for _ in range(blocks)])
        self.cal = nn.Linear(n_cal, out)

    def forward(self, xtab, xcal):
        residual = xtab
        fc = 0.0
        for b in self.blocks:
            back, fore = b(residual)
            residual = residual - back
            fc = fc + fore
        return fc + self.cal(xcal)


# --------------------------- training wrappers ----------------------------
def _targets(w, sp_tr, sp_va, mode, eps):
    if mode == "raw":
        mu, sd = w["ynext"][sp_tr].mean(), w["ynext"][sp_tr].std() + 1e-6
        return (w["ynext"][sp_tr] - mu) / sd, (w["ynext"][sp_va] - mu) / sd, ("raw", mu, sd)
    Ytr = shifted_logratio(w["ynext"][sp_tr], w["anchor"][sp_tr], eps)
    Yva = shifted_logratio(w["ynext"][sp_va], w["anchor"][sp_va], eps)
    return Ytr, Yva, ("alpha", None, None)


def seq_backbone(kind, w, sp_tr, sp_va, sp_te, *, mode, eps, seed=0):
    Xs = torch.tensor(w["Xseq"]).float(); Xc = torch.tensor(w["calnext"]).float()
    Xt = torch.tensor(w["Xtab"]).float()
    a_te = w["anchor"][sp_te]
    Ytr, Yva, meta = _targets(w, sp_tr, sp_va, mode, eps)
    if kind == "tcn":
        model = TCN(w["n_cov"], w["calnext"].shape[1])
        tr, va, te = (Xs[sp_tr], Xc[sp_tr]), (Xs[sp_va], Xc[sp_va]), (Xs[sp_te], Xc[sp_te]); seq = True
    elif kind == "transformer":
        model = TransformerFore(w["n_cov"], w["calnext"].shape[1])
        tr, va, te = (Xs[sp_tr], Xc[sp_tr]), (Xs[sp_va], Xc[sp_va]), (Xs[sp_te], Xc[sp_te]); seq = True
    elif kind == "nbeats":
        model = NBeats(w["Xtab"].shape[1], w["calnext"].shape[1])
        tr, va, te = (Xt[sp_tr], Xc[sp_tr]), (Xt[sp_va], Xc[sp_va]), (Xt[sp_te], Xc[sp_te]); seq = True
    else:
        raise ValueError(kind)
    mse = nn.MSELoss()
    model = _train_torch(model, tr, Ytr, va, Yva, loss_fn=lambda o, y: mse(o, y),
                         seq=True, seed=seed, max_epochs=100, patience=10)
    model.eval()
    with torch.no_grad():
        pred = model(te[0], te[1]).numpy()[:, 0]
    if meta[0] == "raw":
        yhat = pred * meta[2] + meta[1]
    else:
        yhat = invert_alpha(pred, a_te, eps)
    return yhat.astype(np.float32)


# ------------------------------ tree models -------------------------------
def tree_model(kind, w, sp_tr, sp_te, *, mode, eps, seed=0):
    Xtr, Xte = w["Xtab"][sp_tr], w["Xtab"][sp_te]
    a_te = w["anchor"][sp_te]
    if mode == "raw":
        ytr = w["ynext"][sp_tr]
    else:
        ytr = shifted_logratio(w["ynext"][sp_tr], w["anchor"][sp_tr], eps)
    if kind == "lightgbm":
        import lightgbm as lgb
        m = lgb.LGBMRegressor(n_estimators=400, learning_rate=0.05, num_leaves=31,
                              subsample=0.8, colsample_bytree=0.8, random_state=seed, verbose=-1)
    elif kind == "xgboost":
        import xgboost as xgb
        m = xgb.XGBRegressor(n_estimators=400, learning_rate=0.05, max_depth=6,
                             subsample=0.8, colsample_bytree=0.8, random_state=seed, verbosity=0)
    else:
        raise ValueError(kind)
    m.fit(Xtr, ytr)
    pred = m.predict(Xte)
    yhat = pred if mode == "raw" else invert_alpha(pred, a_te, eps)
    return np.asarray(yhat, np.float32)


# ---------------------------- GLM baselines -------------------------------
def glm_model(kind, w, sp_tr, sp_te, *, eps):
    """Raw-target GLM families for positive responses."""
    from sklearn.linear_model import TweedieRegressor, GammaRegressor, PoissonRegressor, QuantileRegressor, Ridge
    Xtr, Xte = w["Xtab"][sp_tr], w["Xtab"][sp_te]
    ytr = w["ynext"][sp_tr] + eps          # strictly positive for GLMs
    if kind == "tweedie":
        m = TweedieRegressor(power=1.5, alpha=1e-3, max_iter=2000)
    elif kind == "gamma":
        m = GammaRegressor(alpha=1e-3, max_iter=2000)
    elif kind == "poisson":
        m = PoissonRegressor(alpha=1e-3, max_iter=2000)
    elif kind == "lognormal":       # OLS on log target
        m = Ridge(alpha=1.0)
        m.fit(Xtr, np.log(ytr))
        return (np.exp(m.predict(Xte)) - eps).astype(np.float32)
    elif kind == "quantile":        # median regression (robust)
        m = QuantileRegressor(quantile=0.5, alpha=1e-3, solver="highs")
    else:
        raise ValueError(kind)
    m.fit(Xtr, ytr)
    return (np.maximum(m.predict(Xte), 0.0) - eps).astype(np.float32)
