"""Clean copy of the manuscript sources: colour-marking macros removed, text unchanged.

usage: python make_clean.py <marked_dir> <clean_dir>
"""
import os, re, shutil, sys

SRC, DST = sys.argv[1], sys.argv[2]
PREAMBLE = re.compile(
    r"\\newif\\ifcolmark \\colmarktrue\n\\ifcolmark\n.*?\\fi\n"
    r"\\newcommand\{\\cA\}\[1\]\{\{\\color\{colA\}#1\}\}\n"
    r"\\newcommand\{\\cB\}\[1\]\{\{\\color\{colB\}#1\}\}\n", re.S)


def unwrap(text):
    out, i = [], 0
    while True:
        m = re.compile(r"\\c[AB]\{").search(text, i)
        if not m:
            out.append(text[i:]); return "".join(out)
        out.append(text[i:m.start()])
        j, depth = m.end(), 1
        while depth:
            c = text[j]
            if c == "\\":
                j += 2; continue
            depth += (c == "{") - (c == "}")
            j += 1
        out.append(unwrap(text[m.end():j - 1]))
        i = j


def clean(text):
    text, n = PREAMBLE.subn("", text)
    text = re.sub(r"^\\color\{col[AB]\}\n", "", text, flags=re.M)
    text = unwrap(text)
    assert not re.search(r"\\c[AB]\b|col[AB]|colmark", text), "marking left"
    return text, n


if os.path.exists(DST):
    shutil.rmtree(DST)
os.makedirs(os.path.join(DST, "tables")); os.makedirs(os.path.join(DST, "figs"))
for name in ["AlphaDeepNet.tex", "Supplementary.tex"]:
    t, n = clean(open(os.path.join(SRC, name), encoding="utf-8").read())
    if name == "AlphaDeepNet.tex" or "\\cA" in open(os.path.join(SRC, name), encoding="utf-8").read():
        assert n == 1, f"preamble block not found in {name}"
    open(os.path.join(DST, name), "w", encoding="utf-8", newline="\n").write(t)
for name in os.listdir(os.path.join(SRC, "tables")):
    t, _ = clean(open(os.path.join(SRC, "tables", name), encoding="utf-8").read())
    open(os.path.join(DST, "tables", name), "w", encoding="utf-8", newline="\n").write(t)
for name in os.listdir(os.path.join(SRC, "figs")):
    if not name.startswith("R5_"):
        shutil.copy2(os.path.join(SRC, "figs", name), os.path.join(DST, "figs", name))
shutil.copy2(os.path.join(SRC, "references.bib"), os.path.join(DST, "references.bib"))
print("clean sources written to", DST)
