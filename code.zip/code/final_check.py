# -*- coding: utf-8 -*-
"""Final publication-readiness check on the compiled PDFs.

Scans the *rendered* text (not the source) for anything that would betray the
peer-review process, plus general submission hygiene.
"""
import re, sys
import fitz

FORBIDDEN = [
    r"\breviewer", r"\breferee", r"\bcolou?r key",
    r"\brevision\b", r"\brevised\b", r"\bminor revision",
    r"response to (the )?(reviewer|comment)", r"\bcomment[s]? \d",
    r"\bin this round\b", r"\bprevious round\b", r"\bprevious version\b",
    r"\bearlier version\b", r"\bas suggested\b", r"\bwe were asked\b",
    r"\bwe have added\b", r"\bwe now add\b", r"\bnewly added\b",
    r"\bMath-29365\b", r"\bsubmitted archive\b", r"\baccompanies the submission\b",
    r"\[Author", r"to be completed by the authors", r"<author>",
    r"\bTODO\b", r"\bFIXME\b", r"\bplaceholder\b", r"\bXXX\b",
]
ALLOW = [  # legitimate uses that are not review-process language
    "run_revision.py", "run revision.py",
    # AIMS masthead / running-footer fields filled in by the publisher
    "Received:", "Accepted:", "Published:", "AIMS Mathematics", "Volume 10",
    "aimspress", "DOI:10.3934",
]

def scan(path):
    doc = fitz.open(path)
    hits = []
    for i, page in enumerate(doc):
        txt = page.get_text()
        flat = re.sub(r"\s+", " ", txt)
        for pat in FORBIDDEN:
            for m in re.finditer(pat, flat, flags=re.I):
                ctx = flat[max(0, m.start() - 60): m.end() + 60]
                if any(a.lower() in ctx.lower() for a in ALLOW):
                    continue
                hits.append((i + 1, pat, ctx.strip()))
    return doc, hits


def main():
    ok = True
    out = []
    def say(s):
        out.append(s)
        try:
            print(s)
        except UnicodeEncodeError:
            print(s.encode("ascii", "replace").decode())
    for path in ["AlphaDeepNet.pdf", "Supplementary.pdf"]:
        doc, hits = scan(path)
        print(f"\n===== {path}  ({len(doc)} pages) =====")
        if hits:
            ok = False
            for pg, pat, ctx in hits:
                say(f"  p{pg}  [{pat}]  ...{ctx}...")
        else:
            say("  no review-process language found")
        # colour census
        from collections import Counter
        c = Counter()
        for p in doc:
            for b in p.get_text("dict")["blocks"]:
                for l in b.get("lines", []):
                    for s in l["spans"]:
                        c[s["color"]] += len(s["text"])
        say("  colours: " + str({f"#{k:06x}": v for k, v in c.most_common(5)}))
        # sparse pages
        sparse = [i + 1 for i, p in enumerate(doc)
                  if len(p.get_text().strip()) < 500 and not p.get_images()]
        say("  sparse pages: " + str(sparse if sparse else "none"))
    print("\nRESULT:", "CLEAN" if ok else "ISSUES FOUND")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
