# -*- coding: utf-8 -*-
"""Generate the response-to-reviewers Word documents:
   Response_to_Reviewers_ALL.docx (combined) and Response_to_Reviewer_{1..5}.docx.
Overlapping comments are answered once (under a primary reviewer) and cross-referenced.
"""
import os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

OUT = os.path.join(os.path.dirname(__file__), "..", "revision")
os.makedirs(OUT, exist_ok=True)

COLORS = {1: RGBColor(0x00, 0x00, 0xD8), 2: RGBColor(0xCC, 0x00, 0x00),
          3: RGBColor(0x00, 0x8C, 0x4C), 4: RGBColor(0x99, 0x00, 0x99),
          5: RGBColor(0xD8, 0x73, 0x00)}
CNAME = {1: "blue", 2: "red", 3: "green", 4: "purple", 5: "orange"}

DECISION = {1: "Major revision", 2: "Minor revision (accept with minor revisions)",
            3: "Revision (clarifying questions)", 4: "Minor revision before acceptance",
            5: "Reject / major revision"}

# Each entry: (comment_text, response_text)
R = {
1: [
 ("The novelty should be narrowed and stated more precisely. AlphaDeepNet is positioned against ResNet, SE, FiLM, attention, transformers, attention U-Net and MoE, but many of these were not designed for positive-state ratio forecasting, so the comparison is not entirely fair. The main contribution appears to be a shifted log-ratio target parameterization for positive-state forecasting.",
  "We agree and have narrowed the framing throughout. The title no longer claims general “Deep Learning”; it now reads “… Adaptive Alpha-Gating, with Validation on Positive-State Forecasting.” The abstract and a new sentence in the Introduction state explicitly that the validated contribution is a shifted log-ratio target parameterization for positive-state forecasting, not a new general-purpose deep-learning architecture. We also added a sentence to the positioning paragraph clarifying that SE, FiLM, attention, U-Nets and MoE were not designed for positive-state ratio forecasting, so Table 1 contrasts design intent and properties, not head-to-head accuracy, and is not a claim of superiority on their native tasks."),
 ("Some theoretical results are algebraic or standard rather than substantially new (positivity, log-state/log-ratio equivalence, ridge closed form, universal approximation, multi-step accumulation). Please distinguish genuinely new contributions from standard properties included for completeness.",
  "Done. We added a paragraph at the start of Section 4 (Theoretical analysis) that explicitly separates the novel core (the shift-induced bias bound; the exact/first-order recovery of the classical power-law model with the O(μ) vs O(μ²) characterisation; and the gate/modality non-identifiability with the log-centering remedy and its new residual-ambiguity bound) from the standard properties stated for completeness (positivity, loss equivalence, closed-form ridge, universal approximation, multi-step accumulation), which we now say follow from definitions or standard arguments and are included because the experiments rely on them."),
 ("The empirical validation does not support the broad scope claimed (scalar/vector/feature/image/temporal/modality). There is no validation on image tensors, segmentation, multimodal, or medical imaging. Tone down the title/abstract/conclusion, or add experiments.",
  "We have toned down the title, abstract, conclusion and limitations rather than claim unvalidated scope. The abstract and the new limitations paragraph state that the feature, spatial and modality operators are developed as theory and the medical-imaging instantiations as future extensions, not demonstrated capabilities, and that the empirical scope is deliberately confined to positive-state forecasting. (This is the same concern raised by Reviewer 5, Comments 2 and 4, and is addressed jointly here.)"),
 ("The experimental scope is still limited (one-step, three environmental/energy datasets). Consider multi-step forecasting, datasets with more frequent zeros, strongly nonstationary series, or other domains.",
  "We substantially broadened the evaluation. We added (i) direct multi-step forecasting at horizons k=1,3,6,12 (new Section 5.8, Table on multi-step; see also our response to Reviewer 2 Comment 4); (ii) a window-length robustness study L=12/24/48 (Section 5.9); (iii) six additional stronger/SOTA backbones and five statistical GLM baselines (Section 5.7). On zeros and nonstationarity: Beijing PM2.5 contains exact zeros (motivating the shift), and the appliance-energy series is highly bursty/nonstationary; the alpha advantage on relative error is confirmed across all of these. Broader domains such as finance and clinical monitoring are now stated as concrete future work."),
 ("RMSE results do not consistently support superiority. Alpha improves MAE/sMAPE but RMSE is not consistent (e.g., Ridge-α on Beijing, LSTM-α on some datasets). The abstract/conclusion should state the main advantage is relative-error, with RMSE dataset- and backbone-dependent.",
  "Agreed; we already reported the trade-offs and have now made the framing precise everywhere. The abstract, one-step section, summary and conclusion state that the parameterization consistently improves relative error (sMAPE) and usually improves MAE, while squared-error improvements are dataset- and backbone-dependent. We added an effect-size table (percentage change vs the matched raw backbone) that quantifies exactly where the method helps. (Reviewer 5 Comment 9 is the same point and is addressed here.)"),
 ("The statistical significance analysis should account for multiple comparisons; report adjusted p-values / FDR control or clarify the tests are exploratory.",
  "Done. The Diebold–Mariano table now reports Benjamini–Hochberg false-discovery-rate-adjusted p-values (a new p_BH column) computed across all comparisons; the absolute- and percentage-loss conclusions survive adjustment. We also state that individual raw p-values are treated as exploratory and that the substantive finding is the consistent sign and magnitude of the effect, complemented by the effect-size table (see our response to Reviewer 3 Comment 1)."),
 ("More competitive baselines are needed: direct ratio prediction, log-return targets, standardized residuals, Gamma/log-normal/Tweedie regression, quantile regression, and strong trees (XGBoost/LightGBM/CatBoost).",
  "We added a comprehensive baseline suite (Section 5.7, Table on stronger/SOTA baselines): LightGBM and XGBoost (each raw and alpha), and Gamma, Tweedie, Poisson and log-normal generalized linear models plus median (quantile) regression. Log-return, standardized-residual and direct-ratio targets are exactly the target-parameterization family already isolated in the transform ablation (log-state, additive-delta and shifted-log-ratio), so we cross-reference that table rather than duplicate it. CatBoost was unavailable in our environment; LightGBM and XGBoost are representative strong-tree baselines. (This also addresses Reviewer 2 Comment 3, Reviewer 4 Comment 5 and Reviewer 5 Comment 3.)"),
 ("The choice of ε needs more systematic justification: a clearer rule, validation-based tuning, and its impact across datasets with different zero frequencies.",
  "We now recommend and apply a concrete, reproducible rule: sweep ε on a geometric grid from the measurement resolution to a fraction of the median target and select the value minimizing validation error. A new table reports the validation-selected ε and the resulting test accuracy on all three datasets, and we discuss the different zero frequencies (Beijing PM2.5 has exact zeros; air quality and energy do not). Selected values lie between 0.01 and 0.12 of the median target and test accuracy is within a few percent of the best grid point. (Reviewer 3 Comment 3 and Reviewer 5 Comment 5 raise the same point and are addressed here.)"),
 ("The medical-imaging and multimodal extensions should be substantially weakened and framed as speculative future directions.",
  "Done. Section 6 has been shortened to a single brief paragraph that explicitly labels the MRI/cardiovascular/breast formulations as speculative future directions, not demonstrated or clinical capabilities, and states that any instantiation would require validation against strong baselines, external testing, uncertainty analysis and bias evaluation. (Reviewer 2 Comment 5 and Reviewer 3 Comment 5 are related and are addressed here and under Reviewer 3 Comment 5.)"),
 ("Interpretability claims require caution: feature gates, spatial maps and modality weights do not automatically have causal or semantic interpretability.",
  "We strengthened the caution. The revised text states that interpretability is not automatic outside the state-ratio setting: a scalar/vector alpha is a relative-change factor, but feature gates, spatial maps and modality weights carry no guaranteed causal or semantic meaning unless additional supervision, constraints or validation are supplied, and should be read with the known cautions about post-hoc explanation."),
 ("Some recent research advances should be included (Microchemical Journal 2026, 221, 116877; IEEE Access 2024, 12, 2224-2235; Ain Shams Eng. J. 2026, 17(1), 103901; Optics and Laser Technology 2026, 198, 114887; Pattern Recognition 2023, 143, 109788).",
  "Added and cited in the literature-boundary discussion as recent deep-learning advances in adjacent domains. We verified and completed the bibliographic details of four of the five (Microchemical Journal, Ain Shams Engineering Journal, Optics and Laser Technology, and Pattern Recognition) via CrossRef; for the IEEE Access 2024, 12, 2224–2235 item we were unable to resolve the exact title/authors from the coordinates provided and have inserted a placeholder entry that the authors will complete at proof. (Reviewer 2 Comment 7 also requests reference additions and is addressed jointly.)"),
],
2: [
 ("Theorem 13 (softmax modality identifiability) only states the simplex constraint “reduces but does not eliminate ambiguity.” Please supply (a) a specific upper bound for the residual ambiguity and (b) feasible correction constraints (e.g., L1/entropy regularization).",
  "We added Proposition 1 immediately after the identifiability theorem. It (i) characterises the admissible reparameterizations under the simplex; (ii) gives an explicit upper bound on the residual per-modality log-scale ambiguity, |log c_m| ≤ log(ρ̄/ρ), when the projection norms are bounded in [ρ,ρ̄]; and (iii) shows that fixing the projection norms removes the ambiguity entirely (c_m = 1) and that an entropy penalty or an ℓ₁ penalty on the logits regularises the weights against degenerate collapse. A short proof is included."),
 ("The density hypothesis in Theorem 7 only mentions “feed-forward networks of unbounded width.” Please supply more practical, implementation-oriented sufficient conditions (activation types, encoder injectivity).",
  "We expanded the density discussion in the Theorem 7 proof with two practical sufficient conditions: (a) any non-polynomial, continuous, locally bounded activation (ReLU, GELU, tanh, SiLU) suffices, whereas polynomial activations do not; and (b) it is enough that the encoder be injective on the compact domain (equivalently, separate its points), e.g. via a left inverse, a skip/identity path preserving the raw inputs, or a sufficiently wide encoder—so that no information needed to represent the target is discarded."),
 ("Add benchmark comparisons with current SOTA time-series models (e.g., N-BEATS, N-HiTS, TFT) to demonstrate practical competitiveness.",
  "We added a stronger/SOTA baseline section (Section 5.7). Each backbone is evaluated in a raw and an alpha version: LightGBM, XGBoost, a temporal convolutional network, a transformer encoder and N-BEATS. The alpha parameterization improves every one of these on relative error, and the best overall models on each dataset are alpha variants of a strong backbone (e.g. N-BEATS-α, XGBoost-α). N-HiTS, the temporal fusion transformer, Informer, Autoformer and DeepAR share the same interface and are cited as further hosts for the alpha gate. Because the alpha operator is a target parameterization rather than an architecture, it composes with and improves SOTA forecasters rather than competing with them. (This addresses Reviewer 1 Comment 7, Reviewer 4 Comment 5 and Reviewer 5 Comment 3.)"),
 ("Theorem 9 establishes a multi-step error bound, but only one-step experiments are reported. Add multi-step results (≥ 3/6/12-step) on at least one dataset.",
  "We added direct multi-step forecasting at horizons k=1,3,6,12 on all three datasets (new Section 5.8 and Table). The relative-error (sMAPE) advantage of the alpha parameterization persists at every horizon, and its log-ratio error grows roughly linearly in k, consistent with the kδ accumulation of Theorem 9—aligning the empirical study with the theory. (Reviewer 3 Comment 2 and Reviewer 1 Comment 4 are addressed here.)"),
 ("Revise the abstract description of “medical imaging instantiations”: explicitly label it an unvalidated future extension.",
  "Done in the abstract (“… the medical-imaging instantiations are stated as future extensions rather than demonstrated capabilities”) and in Section 6. This coincides with Reviewer 1 Comment 9; please see that response for the full description of the change."),
 ("No standard deviation is marked for Ridge and GBM in Table 3. Add a note that no std is reported for deterministic models.",
  "Added a note to the Table 3 caption stating that the persistence, seasonal-naive, ridge and gradient-boosting rows are deterministic given the data and hyperparameters and therefore carry no seed standard deviation, whereas the neural rows are averaged over seeds."),
 ("Add references to current mainstream SOTA time-series forecasting literature.",
  "Added: N-BEATS, N-HiTS, the temporal fusion transformer, Informer, Autoformer, DeepAR, the temporal convolutional network, and LightGBM are now cited where the SOTA baselines are introduced. (See also Reviewer 1 Comment 11 for the additional references requested there.)"),
 ("Please conduct full-language polishing and proofreading of the whole paper.",
  "We performed a full proofreading pass for grammar, consistency of notation and terminology, and flow, and removed residual redundancy (the trivial proofs are collected in an appendix). We are also happy to accept journal copy-editing."),
],
3: [
 ("Can you quantify practical effect sizes (e.g., percentage RMSE/MAE improvement) alongside DM p-values, given the large sample sizes?",
  "Yes. We added an effect-size table reporting the percentage change of each alpha model relative to its matched raw backbone. Relative-error reductions (MAE, sMAPE) are typically 10–30% and positive across essentially all cells, whereas squared-error changes are smaller and occasionally negative on the bursty series—an effect size, not merely a p-value, that quantifies where the parameterization helps. (This complements the FDR-adjusted significance tests requested by Reviewer 1 Comment 6.)"),
 ("Why was multi-step (k>1) forecasting not evaluated on the three real datasets, given the prominence of Theorem 9?",
  "It now is. Please see our response to Reviewer 2 Comment 4: direct multi-step forecasting at k=1,3,6,12 has been added on all three datasets (new Section 5.8), confirming the relative-error advantage at every horizon and the roughly linear growth of log-ratio error predicted by Theorem 9."),
 ("How sensitive are the reported gains to the choice of ε beyond the single Ridge/air-quality sweep?",
  "We extended the ε analysis to all three datasets with a validation-based selection rule and a new table; the gains are stable and the selected ε is portable across datasets with different zero frequencies. Please see our response to Reviewer 1 Comment 8 for the full description."),
 ("Could the log-linear ridge-α closed form be benchmarked against simpler log(y+ε) baselines on all datasets, not just the MLP ablation in Table 4?",
  "The main results table already compares Ridge-α against Ridge (raw) on all three datasets, and the new stronger-baseline table adds LightGBM/XGBoost and GLM comparisons on all datasets. The specific log(y+ε) (“log-state”) target is isolated against the shifted log-ratio in the transform ablation; we note in the text that Ridge-α is the linear instance of that comparison, so the log-state-vs-alpha contrast is now available in both linear and nonlinear forms."),
 ("What specific evidence would falsify the framework's value for the proposed imaging/multimodal extensions in Section 6?",
  "We added an explicit falsification statement (shown in green in Section 6): the framework's value in these extensions would be refuted if, on a task with a measurable positive state, an alpha-gated model failed to match or exceed the matched non-alpha backbone on relative-error and calibration metrics under identical training; if learned alpha maps showed no agreement with established saliency methods or clinically annotated regions; or if the state-ratio interpretation did not transfer across sites/scanners/time under external validation."),
],
4: [
 ("(Assessment) Novel and well-grounded theoretical framework; the shifted log-ratio operator is well motivated, with a complete set of proven properties that distinguish it from heuristic gating.",
  "We thank the reviewer for this positive assessment. The novel-core versus standard-property distinction requested by Reviewer 1 Comment 2 has been added to make the theoretical contribution even clearer."),
 ("(Assessment) Clear positioning against existing gating mechanisms (Residual, SE, FiLM, Attention, MoE) with three unique advantages.",
  "Thank you. We have further sharpened the positioning and clarified (per Reviewer 1 Comment 1) that Table 1 contrasts design intent and properties rather than head-to-head accuracy."),
 ("(Assessment) Comprehensive empirical evaluation across three datasets and four backbones with matched/transform ablations, DM tests and calibration.",
  "Thank you. The evaluation has been broadened further with stronger/SOTA backbones, multi-step forecasting, a window-length study and effect sizes, as detailed below and in the responses to Reviewers 1–3."),
 ("(Assessment) Complete reproducibility and technical details in the appendix.",
  "Thank you. The reproducibility appendix has been updated to include the new baselines, multi-step and window-length protocols, and the additional libraries used (LightGBM, XGBoost)."),
 ("Missing comparison with SOTA time-series models (TCN, Informer, Autoformer) equipped with the proposed alpha gate.",
  "Added. We now evaluate a temporal convolutional network, a transformer encoder and N-BEATS, each with and without the alpha gate, and the alpha gate improves all of them on relative error; Informer and Autoformer are cited as sharing the same interface. Please see our response to Reviewer 2 Comment 3 for the full description and table."),
 ("Incomplete uncertainty ablation: add ablation on different variance-prediction structures and analyze why the shifted log-ratio structure improves calibration on positive-state data.",
  "We added both. The calibration section now explains the mechanism (shown in purple): modelling Gaussian noise in the shifted log-ratio corresponds to a log-normal law on the shifted state whose variance scales with the current level; positive-state series exhibit exactly this multiplicative, level-dependent dispersion, so an input-dependent log-ratio variance matches the data-generating scale, whereas a raw-scale Gaussian head must fit a single additive variance and over/under-covers. We also report a variance-head ablation (input-dependent vs homoscedastic vs raw-scale) in which the input-dependent log-ratio variance gives the best CRPS/NLL on all three datasets."),
 ("The sliding window is fixed to 24 lags. Please test different window lengths (short/medium/long).",
  "Added a window-length robustness study with L=12, 24 and 48 (new Section 5.9 and table): the alpha parameterization improves the raw backbone at every window length and is markedly more stable across L. (Reviewer 5 Comment 8 also raises long-horizon/robustness concerns and is partly addressed here and by the multi-step study.)"),
],
5: [
 ("The novelty of the framework is limited; it primarily integrates established concepts (multiplicative gating, log-space prediction, positivity via shifting) without a fundamentally new mechanism.",
  "We have narrowed and sharpened the novelty claim accordingly. We now present the contribution as a shifted log-ratio target parameterization (with an accompanying operator family and theory) for positive-state forecasting, not a new general-purpose mechanism, and we distinguish the genuinely new theoretical results from standard properties (new paragraph, Section 4). The empirical novelty is that this parameterization improves a wide range of backbones—including SOTA forecasters—on relative error and calibration, which the expanded experiments now demonstrate. Please see our responses to Reviewer 1 Comments 1 and 2."),
 ("The experimental evaluation is insufficient for the broad claims; no image/spatial/sequential/multimodal validation, and the medical-imaging applications remain speculative.",
  "We narrowed the claimed scope to positive-state forecasting and explicitly frame the feature/spatial/modality operators and the medical-imaging formulations as theory and future extensions (title, abstract, limitations and Section 6). Within the forecasting scope we substantially expanded the evidence (stronger/SOTA backbones, multi-step, window-length). Please see our responses to Reviewer 1 Comments 3, 4 and 9."),
 ("The comparison with SOTA methods is incomplete (Transformer, N-BEATS, DeepAR, ratio-aware objectives).",
  "Addressed. We added transformer, N-BEATS, TCN, LightGBM and XGBoost baselines (each raw and alpha), cite DeepAR/N-HiTS/TFT/Informer/Autoformer as sharing the interface, and note that the alpha target is itself a ratio-aware objective evaluated head-to-head against non-ratio targets in the transform ablation. Please see our response to Reviewer 2 Comment 3."),
 ("Claims of general applicability and “Alpha-Gated Deep Learning” appear overstated relative to the scalar/vector forecasting validation.",
  "We removed “Deep Learning” from the title and rescoped it to “Validation on Positive-State Forecasting,” and moderated the abstract/introduction/conclusion so the claimed scope matches the evidence. Please see our responses to Reviewer 1 Comments 1 and 3."),
 ("The shift parameter ε is selected heuristically; no CV procedure or practical guideline is given.",
  "We added a validation-based selection rule applied on every dataset, with a table of selected ε and resulting test accuracy. Please see our response to Reviewer 1 Comment 8."),
 ("The theory provides limited practical insight beyond what follows from the transformation; discuss the conditions under which the inductive bias offers clear advantages.",
  "We now (i) separate the novel results from the standard consequences (Section 4, per Reviewer 1 Comment 2), and (ii) identify empirically when the bias helps: the transform ablation shows the advantage is specific to the anchored relative-change (ratio) structure and concentrates on relative-error and calibration metrics for positive, multiplicative, level-dependent series—precisely the regime the bias targets—while it can be neutral on squared error for bursty data. This makes the conditions for advantage explicit and testable."),
 ("The identifiability analysis and log-centering remedy are insufficiently explored experimentally; is there meaningful impact on optimization/training/performance?",
  "We added a clarification (shown in orange, Section 5.10) supported by the controlled experiment: because the diagonal gate rescaling leaves predictions exactly invariant (to 10^-15), the non-identifiability does not affect optimization, training stability or predictive accuracy—it concerns only the interpretation of absolute gate magnitudes—and log-centering pins the scale at no cost to the predictive metrics. This is precisely why the remedy is worthwhile: it aids interpretation without a performance penalty."),
 ("The paper lacks evaluation on more challenging scenarios (long-horizon forecasting, high-dimensional spatial data, noisy deployment).",
  "We added long-horizon (multi-step k up to 12; Reviewer 2 Comment 4) and receptive-field/robustness (window-length L up to 48; Reviewer 4 Comment 7) studies, and we note in the limitations that high-dimensional spatial data are outside the forecasting scope to which the paper is now confined. Real-world noise is present in all three datasets (missing values, sensor artefacts), which we handle in preprocessing."),
 ("Several conclusions and positioning statements are stronger than the current evidence justifies; gains are dataset- and backbone-dependent.",
  "We moderated the claims throughout so they match the evidence (relative-error advantage consistent; RMSE dataset/backbone-dependent), and added an effect-size table. Please see our response to Reviewer 1 Comment 5."),
 ("The manuscript is well written but has some redundancy; streamline the exposition and let figures/tables emphasize practical trade-offs.",
  "We streamlined the exposition (trivial proofs moved to an appendix; redundant statements trimmed) and added tables that emphasise the practical trade-offs (effect sizes; multi-step and window-length behaviour; stronger-baseline comparison). A full proofreading pass was also performed (Reviewer 2 Comment 8)."),
],
}

INTRO = ("We thank the reviewer for the careful reading and constructive comments, which have "
         "substantially improved the manuscript. Below we respond to each comment (in italics) in turn; "
         "our replies describe the corresponding revisions, which are colour-coded in the revised "
         "manuscript ({col}). Where a comment overlaps another reviewer's, we describe the change once "
         "and cross-reference it to avoid repetition.")


def _set(run, size=11, bold=False, italic=False, color=None, font="Calibri"):
    run.font.size = Pt(size); run.font.bold = bold; run.font.italic = italic
    run.font.name = font
    if color is not None:
        run.font.color.rgb = color


def add_reviewer(doc, rid, standalone):
    h = doc.add_paragraph()
    r = h.add_run(f"Response to Reviewer {rid}")
    _set(r, 15, bold=True, color=COLORS[rid])
    d = doc.add_paragraph(); _set(d.add_run(f"Recommendation: {DECISION[rid]}"), 10, italic=True)
    p = doc.add_paragraph(); _set(p.add_run(INTRO.format(col=CNAME[rid])), 11)
    for i, (ctext, rtext) in enumerate(R[rid], 1):
        cp = doc.add_paragraph()
        _set(cp.add_run(f"Comment {rid}.{i}. "), 11, bold=True, color=COLORS[rid])
        _set(cp.add_run(ctext), 11, italic=True)
        rp = doc.add_paragraph()
        _set(rp.add_run("Response: "), 11, bold=True)
        _set(rp.add_run(rtext), 11)
        doc.add_paragraph()


def make_doc(title):
    doc = Document()
    st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)
    tp = doc.add_paragraph(); tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set(tp.add_run(title), 16, bold=True)
    sub = doc.add_paragraph(); sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set(sub.add_run("Manuscript: “AlphaDeepNet: A Shifted Log-Ratio Theory of Adaptive "
                     "Alpha-Gating, with Validation on Positive-State Forecasting”"), 10, italic=True)
    return doc


def color_key(doc):
    p = doc.add_paragraph()
    _set(p.add_run("Colour key (matching the revised manuscript): "), 10, bold=True)
    for rid in range(1, 6):
        _set(p.add_run(f"Reviewer {rid} ({CNAME[rid]})   "), 10, color=COLORS[rid])
    doc.add_paragraph()


if __name__ == "__main__":
    # combined
    allc = make_doc("Response to Reviewers")
    color_key(allc)
    intro = allc.add_paragraph()
    _set(intro.add_run("We are grateful to all five reviewers. We have revised the manuscript thoroughly; "
                       "every change is colour-coded by reviewer. When a comment overlaps another "
                       "reviewer's, the revision is described once and cross-referenced. Individual "
                       "response letters are also provided per reviewer."), 11)
    for rid in range(1, 6):
        allc.add_page_break()
        add_reviewer(allc, rid, False)
    allc.save(os.path.join(OUT, "Response_to_Reviewers_ALL.docx"))

    for rid in range(1, 6):
        doc = make_doc(f"Response to Reviewer {rid}")
        add_reviewer(doc, rid, True)
        doc.save(os.path.join(OUT, f"Response_to_Reviewer_{rid}.docx"))
    print("Response documents written to", os.path.abspath(OUT))
