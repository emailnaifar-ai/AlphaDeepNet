"""Upload package: Word response letters + editable TeX sources (marked and clean), no PDFs."""
import os, sys, zipfile

D = sys.argv[1]
OUT = os.path.join(D, "NCAA_submission_sources.zip")
SRC = ["AlphaDeepNet.tex", "AlphaDeepNet.bbl", "Supplementary.tex", "references.bib"]
LETTERS = ["Response to Reviewers.docx", "Response to Reviewer 1.docx", "Response to Reviewer 2.docx"]


def add_tree(z, base, arc):
    for f in SRC:
        z.write(os.path.join(base, f), f"{arc}/{f}")
    for sub in ["figs", "tables"]:
        for f in sorted(os.listdir(os.path.join(base, sub))):
            z.write(os.path.join(base, sub, f), f"{arc}/{sub}/{f}")


with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for f in LETTERS:
        z.write(os.path.join(D, f), f)
    add_tree(z, D, "Manuscript - changes marked")
    add_tree(z, os.path.join(D, "Clean version"), "Manuscript - clean")

with zipfile.ZipFile(OUT) as z:
    names = z.namelist()
    assert not any(n.lower().endswith(".pdf") and "/figs/" not in n for n in names)
    print(len(names), "files,", round(os.path.getsize(OUT) / 1024), "KB ->", OUT)
    for n in names:
        if "/figs/" not in n and "/tables/" not in n:
            print("  ", n)
