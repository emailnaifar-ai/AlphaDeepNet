"""One-step forecasting benchmark across three datasets.

Outputs (work/results):
  forecast_<dataset>.csv   per-model test metrics (mean +/- std over seeds)
  dm_<dataset>.csv         Diebold-Mariano tests for the key ablations
"""
import os, sys, json, argparse, warnings
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, os.path.dirname(__file__))
import datasets as D
import models as M
from common import all_metrics, diebold_mariano, set_seed

warnings.filterwarnings("ignore")
torch.set_num_threads(int(os.environ.get("ADN_THREADS", max(1, (os.cpu_count() or 4) // 2))))

RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(RES, exist_ok=True)
EPS = {"beijing": 1.0, "airq": 0.1, "energy": 1.0}


def agg(rows):
    """Average metric rows from multiple seeds -> mean/std dict."""
    keys = [k for k in rows[0] if k not in ("model", "seed")]
    out = {"model": rows[0]["model"]}
    for k in keys:
        vals = np.array([r[k] for r in rows], float)
        out[k] = float(vals.mean()); out[k + "_std"] = float(vals.std())
    return out


def run_dataset(name, seeds_mlp=5, seeds_lstm=3, quick=False):
    eps = EPS[name]
    d = D.LOADERS[name]()
    w = D.make_windows(d, L=24, horizon=12)
    sp = w["split"]
    tr, va, te = sp["train"], sp["val"], sp["test"]
    yte = w["ynext"][te]; ate = w["anchor"][te]
    print(f"\n==== {name}  (eps={eps})  windows: tr={tr.stop-tr.start} "
          f"va={va.stop-va.start} te={te.stop} ====", flush=True)

    def metrics(model, yhat):
        m = all_metrics(yte, yhat, ate, eps); m["model"] = model; return m

    results, preds = [], {}

    # ---- deterministic baselines ----
    preds["Persistence"] = M.persistence(w, te)
    preds["SeasonalNaive"] = M.seasonal_naive(w, te)
    preds["Ridge-Raw"] = M.ridge_raw(w, tr, te)
    preds["Ridge-Alpha(Thm5)"], _ = M.ridge_logratio(w, tr, te, eps)
    if not quick:
        preds["GBM-Raw"] = M.gbm_raw(w, tr, te)
        preds["GBM-Alpha"] = M.gbm_logratio(w, tr, te, eps)
    for k, v in preds.items():
        results.append(metrics(k, v))

    # ---- neural backbones: raw vs alpha (multi-seed) ----
    sm = 1 if quick else seeds_mlp
    sl = 1 if quick else seeds_lstm
    seed_preds = {}
    for tag, mode in [("MLP-Raw", "raw"), ("MLP-Alpha", "alpha")]:
        rows, plist = [], []
        for s in range(sm):
            yhat, _, _ = M.mlp_model(w, tr, va, te, mode=mode, eps=eps, seed=s)
            r = metrics(tag, yhat); r["seed"] = s; rows.append(r); plist.append(yhat)
        results.append(agg(rows)); seed_preds[tag] = np.mean(plist, 0)
    # heteroscedastic alpha (calibration)
    cov_rows = []
    for s in range(sm):
        yhat, _, aux = M.mlp_model(w, tr, va, te, mode="alpha", eps=eps, seed=s, hetero=True)
        from common import picp, mpiw
        cov_rows.append(dict(model="MLP-Alpha-Hetero", **all_metrics(yte, yhat, ate, eps),
                             PICP95=picp(yte, aux["lo"], aux["hi"]),
                             MPIW=mpiw(aux["lo"], aux["hi"]), seed=s))
    results.append(agg(cov_rows))

    for tag, mode in [("LSTM-Raw", "raw"), ("LSTM-Alpha", "alpha")]:
        rows, plist = [], []
        for s in range(sl):
            yhat, _ = M.lstm_model(w, tr, va, te, mode=mode, eps=eps, seed=s)
            r = metrics(tag, yhat); r["seed"] = s; rows.append(r); plist.append(yhat)
        results.append(agg(rows)); seed_preds[tag] = np.mean(plist, 0)

    df = pd.DataFrame(results)
    df.to_csv(os.path.join(RES, f"forecast_{name}.csv"), index=False)

    # ---- Diebold-Mariano: does ALPHA beat the matched RAW backbone? ----
    dm_rows = []
    for a, b in [("MLP-Alpha", "MLP-Raw"), ("LSTM-Alpha", "LSTM-Raw"),
                 ("Ridge-Alpha(Thm5)", "Ridge-Raw")]:
        fa = seed_preds.get(a, preds.get(a)); fb = seed_preds.get(b, preds.get(b))
        if fa is None or fb is None:
            continue
        dm, p = diebold_mariano(yte, fa, fb, h=1, power=2)
        dm_rows.append(dict(alpha_model=a, raw_model=b, DM=dm, p_value=p,
                            favors=("alpha" if dm < 0 else "raw")))
    pd.DataFrame(dm_rows).to_csv(os.path.join(RES, f"dm_{name}.csv"), index=False)

    print(df[["model", "RMSE", "MAE", "sMAPE", "logRMSE"]].to_string(index=False))
    print("DM tests:", json.dumps(dm_rows, indent=0))
    return df, dm_rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=["beijing", "airq", "energy"])
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--seeds_mlp", type=int, default=5)
    ap.add_argument("--seeds_lstm", type=int, default=3)
    args = ap.parse_args()
    for nm in args.datasets:
        run_dataset(nm, args.seeds_mlp, args.seeds_lstm, args.quick)
