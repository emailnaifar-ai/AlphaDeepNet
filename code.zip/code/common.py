"""Shared utilities: reproducible seeding, forecasting metrics, significance tests."""
import numpy as np

try:
    import torch
    _HAS_TORCH = True
except Exception:  # pragma: no cover
    _HAS_TORCH = False


def set_seed(seed: int):
    """Set all relevant RNG seeds for reproducibility."""
    np.random.seed(seed)
    if _HAS_TORCH:
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


# ----------------------------- metrics ------------------------------------
def rmse(y, yhat):
    y, yhat = np.asarray(y, float), np.asarray(yhat, float)
    return float(np.sqrt(np.mean((y - yhat) ** 2)))


def mae(y, yhat):
    y, yhat = np.asarray(y, float), np.asarray(yhat, float)
    return float(np.mean(np.abs(y - yhat)))


def smape(y, yhat):
    """Symmetric MAPE in percent; robust to small/zero values."""
    y, yhat = np.asarray(y, float), np.asarray(yhat, float)
    denom = (np.abs(y) + np.abs(yhat))
    mask = denom > 1e-8
    return float(100.0 * np.mean(2.0 * np.abs(yhat - y)[mask] / denom[mask]))


def logratio_rmse(y, yhat, y_anchor, eps):
    """RMSE in shifted-log-ratio space: log((y+eps)/(anchor+eps))."""
    y = np.asarray(y, float); yhat = np.asarray(yhat, float); a = np.asarray(y_anchor, float)
    yhat_pos = np.maximum(yhat, -eps + 1e-9)  # keep shifted value positive for log
    r_true = np.log(y + eps) - np.log(a + eps)
    r_pred = np.log(yhat_pos + eps) - np.log(a + eps)
    return float(np.sqrt(np.mean((r_true - r_pred) ** 2)))


def all_metrics(y, yhat, y_anchor, eps):
    return dict(RMSE=rmse(y, yhat), MAE=mae(y, yhat), sMAPE=smape(y, yhat),
                logRMSE=logratio_rmse(y, yhat, y_anchor, eps))


# ----------------------- per-observation losses ---------------------------
def loss_vec(y, f, kind="sq"):
    """Per-observation forecast loss. kind in {sq, abs, smape}."""
    y = np.asarray(y, float); f = np.asarray(f, float)
    if kind == "sq":
        return (y - f) ** 2
    if kind == "abs":
        return np.abs(y - f)
    if kind == "smape":
        denom = np.abs(y) + np.abs(f) + 1e-8
        return 2.0 * np.abs(y - f) / denom
    raise ValueError(kind)


# ----------------------- Diebold-Mariano test -----------------------------
def dm_from_losses(l1, l2, h=1):
    """DM test from two per-observation loss vectors (DM<0 favors forecast 1)."""
    from scipy.stats import t as student_t
    d = np.asarray(l1, float) - np.asarray(l2, float)
    n = len(d)
    dbar = d.mean()
    s = np.mean((d - dbar) ** 2)
    for k in range(1, h):
        s += 2.0 * np.mean((d[k:] - dbar) * (d[:-k] - dbar))
    var_dbar = s / n
    if var_dbar <= 0:
        return 0.0, 1.0
    dm = dbar / np.sqrt(var_dbar)
    corr = np.sqrt((n + 1 - 2 * h + h * (h - 1) / n) / n)  # Harvey et al. (1997)
    dm *= corr
    p = 2.0 * student_t.cdf(-abs(dm), df=n - 1)
    return float(dm), float(p)


def diebold_mariano(y, f1, f2, h=1, power=2, kind=None):
    """DM test of equal predictive accuracy under a chosen loss.

    kind in {sq, abs, smape} (overrides `power`); default squared error.
    """
    if kind is None:
        kind = {1: "abs", 2: "sq"}.get(power, "sq")
    return dm_from_losses(loss_vec(y, f1, kind), loss_vec(y, f2, kind), h=h)


# ----------------------- probabilistic scoring ----------------------------
def nll_gaussian(y, mu, sigma):
    """Mean negative log-likelihood of y under N(mu, sigma^2)."""
    y = np.asarray(y, float); mu = np.asarray(mu, float); sigma = np.asarray(sigma, float)
    return float(np.mean(0.5 * np.log(2 * np.pi * sigma ** 2) + (y - mu) ** 2 / (2 * sigma ** 2)))


def crps_gaussian(y, mu, sigma):
    """Closed-form CRPS for a Gaussian predictive (mean over observations)."""
    from scipy.stats import norm
    y = np.asarray(y, float); mu = np.asarray(mu, float); sigma = np.asarray(sigma, float)
    z = (y - mu) / sigma
    c = sigma * (z * (2 * norm.cdf(z) - 1) + 2 * norm.pdf(z) - 1 / np.sqrt(np.pi))
    return float(np.mean(c))


def crps_samples(y, samples):
    """Sample-based CRPS. samples: (N, S). CRPS = E|Y-y| - 0.5 E|Y-Y'|."""
    y = np.asarray(y, float)[:, None]
    S = samples.shape[1]
    term1 = np.mean(np.abs(samples - y), axis=1)
    # E|Y-Y'| via sorted-sample estimator (O(S log S))
    ss = np.sort(samples, axis=1)
    idx = np.arange(S)
    term2 = (2.0 / (S * S)) * np.sum((2 * idx - S + 1) * ss, axis=1)
    return float(np.mean(term1 - 0.5 * term2))


def winkler_score(y, lower, upper, alpha=0.05):
    """Mean Winkler interval score at level (1-alpha). Lower is better."""
    y = np.asarray(y, float); lo = np.asarray(lower, float); up = np.asarray(upper, float)
    width = up - lo
    pen_lo = (2.0 / alpha) * (lo - y) * (y < lo)
    pen_up = (2.0 / alpha) * (y - up) * (y > up)
    return float(np.mean(width + pen_lo + pen_up))


def picp(y, lower, upper):
    """Prediction interval coverage probability (fraction inside [lower, upper])."""
    y = np.asarray(y, float)
    return float(np.mean((y >= np.asarray(lower)) & (y <= np.asarray(upper))))


def mpiw(lower, upper):
    """Mean prediction interval width."""
    return float(np.mean(np.asarray(upper) - np.asarray(lower)))
